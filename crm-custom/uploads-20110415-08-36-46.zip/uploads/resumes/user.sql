-- phpMyAdmin SQL Dump
-- version 3.3.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 27, 2010 at 12:00 PM
-- Server version: 5.1.46
-- PHP Version: 5.3.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `club`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `userid` int(5) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `salt` varchar(3) COLLATE latin1_general_ci NOT NULL,
  `nume` text COLLATE latin1_general_ci NOT NULL,
  `prenume` text COLLATE latin1_general_ci NOT NULL,
  `nick` text COLLATE latin1_general_ci NOT NULL,
  `phone` text COLLATE latin1_general_ci NOT NULL,
  `email` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `preferinte` text COLLATE latin1_general_ci NOT NULL,
  `anulnasterii` text COLLATE latin1_general_ci NOT NULL,
  `localitate` text COLLATE latin1_general_ci NOT NULL,
  `judet` text COLLATE latin1_general_ci NOT NULL,
  `observatii` text COLLATE latin1_general_ci NOT NULL,
  `active` tinyint(4) NOT NULL,
  `confirmed` tinyint(4) NOT NULL DEFAULT '0',
  `avatar` text COLLATE latin1_general_ci NOT NULL,
  `photo1` text COLLATE latin1_general_ci NOT NULL,
  `photo2` text COLLATE latin1_general_ci NOT NULL,
  `photo3` text COLLATE latin1_general_ci NOT NULL,
  `rank` text COLLATE latin1_general_ci NOT NULL,
  `functie` text COLLATE latin1_general_ci NOT NULL,
  `date_registered` date NOT NULL,
  `date_updated` date NOT NULL,
  `date_logged` date NOT NULL,
  `islogged` tinyint(1) NOT NULL,
  `score` int(11) NOT NULL,
  `option_updates` int(11) NOT NULL DEFAULT '15' COMMENT 'Number of updates on homepage',
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=83 ;
