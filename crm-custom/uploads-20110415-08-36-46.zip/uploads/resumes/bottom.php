				</div>
			</div>
			<div id="sidebar-left-both" class="sidebar">

<div class="block">
	<h2>Top balti (comentarii)</h2>
	<div class="content">
		<ul>
			<?php
			$sqla = "SELECT * FROM `balti`";
			$resulta = mysql_query($sqla);
			while($rowa = mysql_fetch_array($resulta)) {
				$sql = "SELECT * FROM `comments` WHERE post_id_fk='".$rowa['bid']."' AND status='1'";
				$bebe = mysql_query($sql);
				$rowb = mysql_fetch_array($bebe);
				$comentarii = mysql_num_rows($bebe);

				$sqlupdate = "UPDATE articole_statistici SET comentarii='$comentarii' WHERE balta='".$rowa['bid']."'";
				$resultupdate = mysql_query($sqlupdate);

				// MOTOR DE ADAUGARE BALTI IN STATISTICI. ATENTIE! TABELUL 'articole_statistici' TREBUIE GOLIT INAINTE DE RULAREA ACESTUI COD!
		//		 $sqli = "INSERT INTO articole_statistici (sid, balta, comentarii) VALUES (NULL, ".$rowa['bid'].", ".$comentarii.")";
		//		 $resulti = mysql_query($sqli);
			}

			$sql = "SELECT * FROM articole_statistici ORDER BY comentarii DESC LIMIT 10";
			$result = mysql_query($sql);

			while($row = mysql_fetch_array($result)) {
				$sqlx = "SELECT * FROM `balti` WHERE bid='".$row['balta']."'";
				$resultx = mysql_query($sqlx);
				$rowx = mysql_fetch_array($resultx);

				echo '<li>&raquo; <a href="balti.php?id='.$rowx['bid'].'">'.$rowx['nume'].'</a> <small style="color:#666666; float:right;">('.$row['comentarii'].')</small></li>';
			}
			?>
		</ul>
	</div>
</div>

<div class="block">
	<h2>Top comentatori</h2>
	<div class="content">
		<ul>
			<?php
			$sqlg = "SELECT com_name,count(*) FROM comments WHERE status = '1' GROUP BY com_name";
			$resultg = mysql_query($sqlg);
			while($rowg = mysql_fetch_array($resultg)) {
				$sqli = "UPDATE comments_statistici SET comentator = '".$rowg[0]."', comentarii = '".$rowg[1]."' WHERE comentator = '".$rowg[0]."'";
				$resulti = mysql_query($sqli);
			}

			$sql = "SELECT * FROM comments_statistici ORDER BY comentarii DESC LIMIT 10";
			$result = mysql_query($sql);

			while($row = mysql_fetch_array($result)) {
				echo '<li>&raquo; '.$row[1].' <small style="color:#666666; float:right;">('.$row['comentarii'].')</small></li>';
			}
			?>
		</ul>
	</div>
</div>

<!-- INCEPUT COMENTARII RECENTE: FORUM -->
<?php require_once('MyBBLatest.class.php');?>
<div class="block">
	<h2>Nou pe <strong>forum</strong></h2>
	<div class="content">
		<?php echo $mybb->threads();?>
	</div>
</div>
<?php @mysql_select_db('gigicta_club');?>
<!-- SFARSIT COMENTARII RECENTE: FORUM -->

<div class="block">
	<h2>Articole</h2>
	<div class="content">
		<ul>
			<?php
			$sql = "SELECT * FROM articole WHERE categorie = 'articole'";
			$result = mysql_query($sql);

			while($row = mysql_fetch_array($result)) {
				echo '<li>&raquo; <a href="page.php?id='.$row['post_id'].'">'.$row['titlu'].'</a></li>';
			}
			?>
		</ul>
	</div>
</div>

<div class="block">
	<h2>Publicitate</h2>
	<div class="content" style="text-align:center">
		<script type="text/javascript"><!--
		google_ad_client = "pub-3656690446237603";
		/* ps-stanga-wide, 160x600, created 07/11/09 */
		google_ad_slot = "7546839847";
		google_ad_width = 160;
		google_ad_height = 600;
		//-->
		</script>
		<script type="text/javascript" src="http://pagead2.googlesyndication.com/pagead/show_ads.js"></script>
	</div>
</div>

</div>
</div>

<div id="sidebar-right" class="sidebar">

<?php require_once('MyBBLatest.class.php');?>
<div class="block">
	<h2>Lacuri si balti din Romania</h2>
	<div class="content">
		<?php
		$balti = mysql_query("SELECT DISTINCT judet FROM balti ORDER BY judet");
		echo '<form method="post" action="balti.list.php">';
		echo '<select name="judet" class="field">';
		while($brow = mysql_fetch_array($balti)) {
			$judet = $brow['judet'];
			$n1 = mysql_query("SELECT * FROM balti WHERE judet = '$judet'");
			$n2 = mysql_num_rows($n1);
			if($n2 > 0)
				echo '<option value="'.$judet.'">'.$judet.' ('.$n2.')</option>';
		}
		echo '</select>';
		echo '<input type="submit" class="signin_submit" name="submit" value="Go" />';
		echo '</form>';
		?>
	</div>
</div>

<?php
if(is_authed()) {
	$result = mysql_query("SELECT rank FROM user WHERE username='$username'");
	$row = mysql_fetch_array($result);
?>
	<div class="block-red">
		<h2>Bine ai venit!</h2>
		<div class="content-red">
			<ul>
				<?php
				if($row['rank']=='0') {
					$rescomments = mysql_query("SELECT * FROM comments WHERE status='0'");
					$rowcomments = mysql_num_rows($rescomments);

					echo '<li>&raquo; <a href="admin">Administrare</a></li>';
					echo '<li>&raquo; '.$rowcomments.' comentarii in asteptare</li>';
					echo '<li>&raquo; <a href="balta.php">Balta <sup>ALPHA</sup></a></li>';
				}
				?>
			</ul>
			<?php
			$contentresult = mysql_query("SELECT * FROM content");
			$contentrow = mysql_fetch_array($contentresult);
			echo '<img src="includes/timthumb.php?src='.$sitedomain.'temporary/full/'.$global_avatar.'&amp;h=50&amp;w=50&amp;zc=1&amp;q=100" class="thumb" style="margin-right: 4px; margin-bottom: 16px; float: left" alt="" />';
			echo '<a href="detail-view.php?userid='.$global_userid.'"><strong>'.$_SESSION['username'].'</strong></a> (<a href="logout.php">Iesire</a>)<br />';
			echo '<a href="cpanel.php">Profil membru</a><br style="clear: both" />';
			?>
			&raquo; <a href="balti.add.php">Adauga o balta</a> <sup style="color: #F00; font-weight: bold">NOU!</sup><br />
			&raquo; <a href="page.php?id=563">Femeile saptamanii</a><br />
			&raquo; <a href="cote.php">Cotele apelor Dunarii</a><br />
			<!--<li>&raquo; <a href="evenimente.php">Evenimentele mele</a></li>-->
		</div>
	</div>
<?php }?>

<div class="block">
	<h2>Statistici</h2>
	<div class="content">
		<?php //include('includes/stats-online.php');?>
		<div id="online"></div>
	</div>
</div>

<?php if(!is_authed()) {?>
<div class="block">
	<h2>Intra in cont</h2>
	<div class="content">
		<form method="post" name="registerform" id="registerform" action="login.php">
			<p>
				<input type="text" name="username" id="username" value="" /> 
				<label for="username">Utilizator</label>
			</p>
			<p>
				<input type="password" name="password" id="password" value="" /> 
				<label for="password">Parola</label>
			</p>
			<p class="remember">
				<input type="submit" class="signin_submit" name="submit" value="Login" /> <a href="register.php">Membru nou?</a><!-- | <a href="#">Am uitat parola</a>-->
			</p>
		</form>
	</div>
</div>
<?php }?>

<div class="block">
	<h2>Chat <sup>BETA</sup></h2>
	<div class="content">
		<?php if(is_authed()) {?><p style="text-align: right"><a href="arhiva-chat.php">Arhiva chat</a></p><?php }?>
		<?php if(!is_authed()) {?><p style="text-align: right">Doar membrii pot vedea arhiva chat-ului!</p><?php }?>
		<?php
		if(is_authed()) {
			$username = $_SESSION['username'];
		}
		if(!is_authed()) {
			$pescar = rand(1,999);
			$username = 'Pescar '.$pescar;
		}
		?>
		<iframe src="shoutbox/index.php?user=<?php echo $username;?>" width="186" height="400" frameborder="0" class="rounded"></iframe>
	</div>
</div>

<?php if((isset($_GET['id'])) && ($_SERVER['SCRIPT_NAME'] == '/page.php')) {?>
<div class="block">
	<h2>Articole asemanatoare</h2>
	<div class="content">
 		<ul>
			<?php
			$sql_related = "SELECT * FROM articole WHERE categorie='$categorie'";
			$result_related = mysql_query($sql_related);

			while($row_related = mysql_fetch_array($result_related)) {
				if($row_related['post_id'] == $_GET['id'])
					echo '<li>&raquo; <a href="page.php?id='.$row_related['post_id'].'"><strong>'.$row_related['titlu'].'</strong></a></li>';
				else
					echo '<li>&raquo; <a href="page.php?id='.$row_related['post_id'].'">'.$row_related['titlu'].'</a></li>';
			}
			?>
		</ul>
	</div>
</div>
<?php }?>

<div class="block">
	<h2>Momeli/Monturi</h2>
	<div class="content">
 		<ul>
			<?php
			$sql = "SELECT * FROM articole WHERE categorie = 'momelimonturi'";
			$result = mysql_query($sql);

			while($row = mysql_fetch_array($result)) {
				echo '<li>&raquo; <a href="page.php?id='.$row['post_id'].'">'.$row['titlu'].'</a></li>';
			}
			?>
		</ul>
	</div>
</div>

<div class="block">
	<h2>Prieteni</h2>
	<div class="content">
		<ul>
			<?php
			$sql = "SELECT * FROM articole WHERE categorie = 'prieteni'";
			$result = mysql_query($sql);

			while($row = mysql_fetch_array($result)) {
				echo '<li>&raquo; <a href="page.php?id='.$row['post_id'].'">'.$row['titlu'].'</a></li>';
			}
			?>
		</ul>
	</div>
</div>

<div><script type="text/javascript"><!--
google_ad_client = "pub-3656690446237603";
/* 200x200, created 06/01/10 */
google_ad_slot = "7829076322";
google_ad_width = 200;
google_ad_height = 200;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div>

<div class="block">
	<h2>Membri</h2>
	<div class="content">
		<?php
		$result = mysql_query("SELECT * FROM user WHERE active='1' ORDER BY userid DESC LIMIT 100",$database);
		while ($row = mysql_fetch_array($result)) {
			if($row['avatar']!='') {
				$userthumb = str_replace(' ','%20',$row['avatar']);
				echo '<img src="includes/timthumb.php?src='.$sitedomain.'temporary/full/'.$userthumb.'&amp;h=30&amp;w=30&amp;zc=1&amp;q=100" class="thumb" style="margin: 2px" alt="" />';
			}
		}
		?>
		<br />
		<small>
		<?php
		$result = mysql_query("SELECT * FROM user WHERE active='1' ORDER BY userid DESC LIMIT 5",$database);
		while ($row = mysql_fetch_array($result)) {
			if (is_authed()) {
				echo '<span class="i-row-date"><a href="detail-view.php?userid='.$row['userid'].'">'.$row['nume'].' '.$row['prenume'].'</a></span>, ';
			}
			if (!is_authed()) {
				echo '<span class="i-row-date">'.$row['nume'].' '.$row['prenume'].'</span>, ';
			}
		}
		?>
		<br />
		&raquo; <a href="lista-membri.php">Vezi toti membrii</a>
		</small>
	</div>
</div>

<div class="block">
	<h2>Documente utile</h2>
	<div class="content">
		<ul>
			<li>&raquo; <a href="page.php?id=577">ANPA 2010</a></li>
			<li>&raquo; <a href="page.php?id=564">Prohibitie 2010</a></li>
			<li>&raquo; <a href="page.php?id=562">Subventii balti</a></li>
			<li>&raquo; <a href="documente/Proiect_ordin_pescuit_sportiv.pdf">Permis pescuit</a></li>			
			<li>&raquo; <a href="documente/Legea-246-2005.doc">Legea 246/2005</a></li>
			<li>&raquo; <a href="documente/OUG-26-2000-Asociatii-Fundatii.pdf">OUG 26/2000</a></li>
			<li>&raquo; <a href="documente/decizii-filiala-constanta.pdf">Decizii filiala Cta</a></li>
			<li>&raquo; <a href="documente/decizii-filiala-tulcea.pdf">Decizii filiala TL</a></li>
			<li>&raquo; <a href="documente/Prohibitie_2009.doc">Prohibitie 2009</a></li>
			<li>&raquo; <a href="documente/Act-Constitutiv-Club.doc">Act constitutiv club</a></li>
			<li>&raquo; <a href="documente/Statut-club.doc">Statut club</a></li>
			<li>&raquo; <a href="page.php?id=4">Legea 192/2001</a></li>
		</ul>
	</div>
</div>

<div class="block">
	<h2>Retete culinare</h2>
	<div class="content">
		<?php $feed = new SimplePie('http://www.havanacafe.ro/retete-din-carne-de-peste/feed/');?>
		<ul>
			<?php foreach ($feed->get_items(0, 5) as $item): ?>
				<li>&raquo; <a href="<?php print $item->get_permalink();?>"><?php print substr(($item->get_title()),0,23);?> [...]</a></li>
			<?php endforeach; ?>
		</ul>
	</div>
</div>

		</div>
	</div>
</div>

<div id="footer1">&nbsp;</div>
<div id="footer2">
	<p>&copy;2002-<?php echo date('Y');?> <strong>Pescuitul Sportiv in Dobrogea</strong>. Toate drepturile rezervate.</p>
	<p><a href="parteneri.php">Parteneri</a> | <a href="contact.php">Contact</a> | <a href="termeni.php">Termeni de utilizare</a></p>
<p>

<!--/ GTop.ro - GTop.ro, the G-SPOT of web statistics (begin) v2.1/--> 
<script type="text/javascript"> 
var site_id = 8813;
var gtopSiteIcon = 7;
</script>
<script type="text/javascript" src="http://fx.gtop.ro/js/gTOP.js?v=2"></script>
<!--/ GTop.ro - GTop.ro, the G-SPOT of web statistics (end) v2.1/-->
</p>
</div>
	<script type="text/javascript" charset="utf-8" src="js/jquery.hoverIntent.minified.js"></script>
    <script type="text/javascript" charset="utf-8" src="js/jquery.lightbox-0.5.pack.js"></script>
	<script type="text/javascript" charset="utf-8" src="js/jquery.prettyPhoto.js"></script>
	<script type="text/javascript" charset="utf-8" src="js/jquery.cycle.lite.1.0.min.js"></script>
	<script type="text/javascript" charset="utf-8" src="js/chat.js"></script>
	<script type="text/javascript" charset="utf-8" src="js/functions.js"></script>
</body>
</html>
