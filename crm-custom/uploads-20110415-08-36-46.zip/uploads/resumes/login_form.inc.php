<?php if (isset($login_error)) { ?>
	<?php echo $login_error; ?>
<?php } ?>

<form name="registerform" id="registerform" action="#" method="post">
	<p>
		<label>Utilizator <input type="text" name="username" id="username" value="" <?php if (isset($_POST['username'])) { ?> value="<?php echo $_POST['username']; ?>" <?php } ?> /></label> | 
		<label>Parola <input type="password" name="password" id="password" value="" /></label> | 
		<input type="submit" id="button" name="submit" value="Login" />
	</p>

	<p id="reg_passmail">Intra in cont. Daca nu ai un cont, <a href="register.php">fa-ti unul acum</a>.</p>
</form>
