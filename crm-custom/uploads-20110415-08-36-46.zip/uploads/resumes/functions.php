<?php
// Refresh page - redirection to 'index.php'
function redirect() {
	echo '<meta http-equiv="refresh" content="0; url=index.php" />';
}

// Mutiuser routines
// Salt Generator
function generate_salt() {
	// Declare $salt
	$salt = '';
	// And create it with random chars
	for ($i = 0; $i < 3; $i++) {
		$salt .= chr(rand(35, 126));
	}
	return $salt;
}

function user_register($username, $nume, $prenume, $anulnasterii, $email, $localitate, $judet, $password) {
	// Get a salt using our function
	$salt = generate_salt();
	// Now encrypt the password using that salt
//	$encrypted = md5(md5($password).$salt);
	// And lastly, store the information in the database
//	$query = "insert into user (username, password, salt) values ('$username', '$encrypted', '$salt')";
	$date1 = date('Y-m-d');
	$date2 = date('Y-m-d');
	$username = strtolower($username);		// Transforms "heLLO wOrLD" into "Hello World"
	$email = strtolower($email);		// Transforms "heLLO wOrLD" into "Hello World"
	$localitate = ucwords(strtolower($localitate));		// Transforms "heLLO wOrLD" into "Hello World"
	$judet = ucwords(strtolower($judet));		// Transforms "heLLO wOrLD" into "Hello World"
	$nume = ucwords(strtolower($nume));	// Transforms "heLLO wOrLD" into "Hello World"
	$prenume = ucwords(strtolower($prenume));	// Transforms "heLLO wOrLD" into "Hello World"
	$query = "INSERT INTO user (username, nume, prenume, anulnasterii, email, localitate, judet, password, salt, active, date_registered, date_updated) VALUES ('$username', '$nume', '$prenume', '$anulnasterii', '$email', '$localitate', '$judet', '$password', '$salt', '0', '$date1', '$date2')";
	mysql_query ($query) or die ('Could not create user.');

	$last_id = mysql_insert_id();
	// Email confirmare
	$message = 'Iti multumim pentru inscrierea in Clubul Pescarilor Sportivi din Dobrogea.<br /><br />';
	$message .= 'Pentru a finaliza inscrierea si a activa contul da click pe linkul de mai jos:<br /><br />';
	$message .= '<a href="http://www.pescuitulsportiv.ro/confirm.php?id='.$last_id.'">Activeaza cont!</a><br /><br />';
	$message .= 'Daca linkul nu functioneaza sau nu este vizibil copiaza linkul <strong>http://www.pescuitulsportiv.ro/confirm.php?id='.$last_id.'</strong> la adresa browser-ului.';
	$message .= '<br /><br />Echipa Pescuitul Sportiv in Dobrogea';
	$subject = "Confirmare inscriere Pescuitul Sportiv in Dobrogea";

	$header = 'MIME-Version: 1.0'."\r\n";
	$header .= 'Content-type: text/html; charset=utf-8'."\r\n";
	$header .= "From: contact@pescuitulsportiv.ro\n";
	mail($email,$subject,$message,$header);
}

function user_login($username, $password) {
	// Try and get the salt from the database using the username
	$query = "select salt from user where username='$username' limit 1";
	$result = mysql_query($query);
	$user = mysql_fetch_array($result);
	// Using the salt, encrypt the given password to see if it
	// matches the one in the database
	$encrypted_pass = md5(md5($password).$user['salt']);
	// Try and get the user using the username & encrypted pass
//	$query = "select userid, username from user where username='$username' and password='$encrypted_pass'";
	$query = "SELECT userid, username, confirmed FROM user WHERE username='$username' AND password='$password' AND confirmed='1'";
	$result = mysql_query($query);
	$user = mysql_fetch_array($result);
//	if($user['confirmed']=='0') {
//		'Contul tau nu a fost activat. Foloseste linkul din casuta de email pentru a-l activa.';
//		return false;
//	}
	$numrows = mysql_num_rows($result);
	// Now encrypt the data to be stored in the session
	$encrypted_id = md5($user['userid']);
	$encrypted_name = md5($user['username']);
	// Store the data in the session
	$_SESSION['userid'] = $userid;
	$_SESSION['username'] = $username;
	$_SESSION['encrypted_id'] = $encrypted_id;
	$_SESSION['encrypted_name'] = $encrypted_name;
	if ($numrows == 1) {
		return 'Correct';
	}
	else {
		return false;
	}
}

function user_logout() {
	$user = $_SESSION['username'];
	$result = mysql_query("SELECT * FROM user WHERE username='$user';");
	$row = mysql_fetch_array($result);
	$a = $row['userid'];
	mysql_query("UPDATE user SET islogged='0' WHERE userid='$a' LIMIT 1;");

	// End the session and unset all vars
	session_unset ();
	session_destroy ();
}

function is_authed() {
	// Check if the encrypted username is the same
	// as the unencrypted one, if it is, it hasn't been changed
	if (isset($_SESSION['username']) && (md5($_SESSION['username']) == $_SESSION['encrypted_name'])) {
		return true;
	}
	else {
		return false;
	}
}

/**********************************************************************/
function restrictedAccess() {
	echo '<h2>Acces restrictionat!</h2><p>Pentru a accesa aceasta pagina, trebuie sa fii membru.</p><p><a href="register.php"><strong>Inregistreaza-te</strong></a> acum sau <a href="login.php"><strong>intra in contul tau</strong></a>.</p><p>Daca ai ajuns pe aceasta pagina dintr-un motor de cautare sau un link de pe un alt site, <a href="contact.php">contacteaza-ne</a> acum.</p>';
}




function date_diff_update($str_start, $str_end) {
	$str_start = strtotime($str_start); // The start date becomes a timestamp
	$str_end = strtotime($str_end); // The end date becomes a timestamp

	$nseconds = $str_end - $str_start; // Number of seconds between the two dates
	$ndays = round($nseconds / 86400); // One day has 86400 seconds
	$nseconds = $nseconds % 86400; // The remainder from the operation
	$nhours = round($nseconds / 3600); // One hour has 3600 seconds
	$nseconds = $nseconds % 3600;
	$nminutes = round($nseconds / 60); // One minute has 60 seconds, duh!
	$nseconds = $nseconds % 60;

	// echo $ndays." zile, ".$nhours." ore.";

	if($ndays<=90) {
		//return 'membru nou';
		$stars = 0;
		return '';
	}
	elseif(($ndays>90) && ($ndays<=180)) {
		//return 'membru mai vechi';
		$stars = 1;
		return '<img src="images/star.png" alt="" />';
	}
	elseif(($ndays>180) && ($ndays<=730)) {
		//return 'membru mai vechi';
		$stars = 2;
		return '<img src="images/star.png" alt="" /><img src="images/star.png" alt="" />';
	}
	elseif($ndays>730) {
		//return 'membru mai vechi';
		$stars = 3;
		return '<img src="images/star.png" alt="" /><img src="images/star.png" alt="" /><img src="images/star.png" alt="" />';
	}
}

function date_diff_login($str_start, $str_end)
{

$str_start = strtotime($str_start); // The start date becomes a timestamp
$str_end = strtotime($str_end); // The end date becomes a timestamp

$nseconds = $str_end - $str_start; // Number of seconds between the two dates
$ndays = round($nseconds / 86400); // One day has 86400 seconds
$nseconds = $nseconds % 86400; // The remainder from the operation
$nhours = round($nseconds / 3600); // One hour has 3600 seconds
$nseconds = $nseconds % 3600;
$nminutes = round($nseconds / 60); // One minute has 60 seconds, duh!
$nseconds = $nseconds % 60;

//echo 'Ultima oara vazut acum '.$ndays." zile.";

if($ndays<=90) {return ' activ';}
else if($ndays>=90) {return ' inactiv';}
else if($ndays>=365) {return ' sters';}
}




function nicetime($date) {
	if(empty($date)) {
		return "No date provided";
	}
	$periods = array("secunda", "minut", "ora", "zi", "saptamana", "luna", "an", "decada");
	$lengths = array("60","60","24","7","4.35","12","10");
	$now = time();
	$unix_date = strtotime($date);
	// check validity of date
	if(empty($unix_date)) {   
		return "Bad date";
	}
	// is it future date or past date
	if($now > $unix_date) {   
		$difference = $now - $unix_date;
		$tense = "acum";
	}
	else {
		$difference = $unix_date - $now;
		$tense = "from now";
	}
	for($j = 0; $difference >= $lengths[$j] && $j < count($lengths)-1; $j++) {
		$difference /= $lengths[$j];
	}
	$difference = round($difference);
	if($difference != 1) {
//		$periods[$j] .= "s";
		$periods = array("secunde", "minute", "ore", "zile", "saptamani", "luni", "ani", "decade");
	}
	return "{$tense} $difference $periods[$j]";
}



function showProfile($userid, $sitedomain) {
	$result = mysql_query("SELECT * FROM user WHERE userid='$userid'");
	$row = mysql_fetch_array($result);
	?>
	<div class="profilebox">
		<h3>Profil membru</h3>
		<div class="profile-photo">
			<?php
			if($row['avatar']!='') {
				echo '<a href="temporary/full/'.$row['avatar'].'"><img src="includes/timthumb.php?src='.$sitedomain.'temporary/full/'.$row['avatar'].'&amp;h=100&amp;w=100&amp;zc=1&amp;q=100" alt="" /></a>';
			}
			else {
				echo '<img src="temporary/full/avatar-blank.png" alt="" />';
			}
			?>
		</div>
		<div class="profile-main">
			<strong><?php echo $row['nume'].' '.$row['prenume'];?></strong> <?php if (is_authed()) {?><a href="javascript:void(0)" onclick="javascript:chatWith('<?php echo $row['username'];?>')"><img src="images/icon-shout.png" alt="" title="Discuta privat cu <?php echo $row['username'];?>" style="vertical-align: middle" /></a><?php }?><br />
			<?php $age = date('Y')-$row['anulnasterii'];?>
			<?php 
			if($row['anulnasterii']!='') {
				echo 'Varsta: '.$age.' ani';
			}
			else {
				echo 'Varsta: -';
			}
			?>
			<br />
			<?php echo $row['localitate'];?>, <?php echo $row['judet'];?>
		</div>
		<div class="profile-photo-multiple">
			<?php
			$result_foto = mysql_query("SELECT * FROM balti_recorduri WHERE autor='$userid'");
			while($row_foto = mysql_fetch_array($result_foto)) {
				echo '<a href="temporary/full/'.$row_foto['foto'].'"><img src="includes/timthumb.php?src='.$sitedomain.'temporary/full/'.$row_foto['foto'].'&amp;h=50&amp;w=50&amp;zc=1&amp;q=100" alt="" /></a>';
			}
			?>
		</div>
		<div class="profile-greyedout">
			Inregistrat la <?php echo $row['date_registered'];?> | Actualizat la <?php echo $row['date_updated'];?> | Ultima logare: <?php echo $row['date_logged'];?>
		</div>
		<div class="profile-greyedout">
			Acesta este profilul tau public. Informatii precum telefon sau adresa de email nu sunt facute publice.
		</div>
		<div class="profile-greyedout">
			<strong>Statistici: in curand!</strong>
		</div>
		<h3>Filme adaugate</h3>
		<div class="profile-photo-multiple">
			<?php
			$sql = mysql_query("SELECT * FROM tv WHERE member='".$row['username']."'");
			while($myrow = mysql_fetch_array($sql)) {
				echo '<a href="#" onclick="window.open(\'tv-popup.php?id='.$myrow['id'].'\',\'mywindow\',\'status=0,toolbar=0,scrollbars=1,width=740,height=500\'); return false;"><img src="includes/timthumb.php?src='.$sitedomain.'tv/icons/'.$myrow['filename'].'.jpg&amp;h=50&amp;w=50&amp;zc=1&amp;q=100" alt="" /></a> ';
			}
			?>
		</div>
	</div>
	<?php
	}
?>
