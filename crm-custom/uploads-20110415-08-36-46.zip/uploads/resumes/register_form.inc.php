<?php
if(isset($reg_error)) {
	echo $reg_error;
}

$n1 = rand(0, 10);
$n2 = rand(0, 10);
?>
<p><strong>Atentie!</strong> Utilizand acest formular, poti sa devii membru al site-ului <em>www.pescuitulsportiv.ro</em>. Statutul de membru al site-ului iti da dreptul sa accesezi sectiunea <strong>chat</strong>, sa adaugi evenimente, anunturi si sa urmaresti emisiuni online.</p>
<p>Pentru a deveni membru al <strong>Clubului Pescarilor Sportivi din Dobrogea</strong>, trebuie sa completezi detaliile din sectiunea <strong>profil</strong>, precum nick, data nasterii sau localitate. Statutul de membru al clubului iti aduce statistici avansate, noutati ale clubului si multe alte avantaje.</p>
<p>Campurile marcate cu <span style="color: #F00">*</span> sunt obligatorii!</p>
<form action="register.php" method="post">
<p>
	<label for="username">Utilizator <span style="color: #F00">*</span></label><br />
	<input type="text" size="25" maxlength="20" name="username" name="id" /></label><small style="font-style:italic; color:#999">(exemplu: pescarul)</small><br />
	<small style="color:#999">Maxim 20 de caractere.</small>
</p>
<p>
	<label for="nume">Nume <span style="color: #F00">*</span></label><br />
	<input type="text" size="25" maxlength="30" name="nume" id="nume" /><small style="font-style:italic; color:#999">(exemplu: Ionescu)</small><br />
	<small style="color:#999">Maxim 30 de caractere.</small>
</p>
<p>
	<label for="prenume">Prenume <span style="color: #F00">*</span></label><br />
	<input type="text" size="25" maxlength="30" name="prenume" id="prenume" /><small style="font-style:italic; color:#999">(exemplu: George)</small><br />
	<small style="color:#999">Maxim 30 de caractere.</small>
</p>
<p>
	<label for="anulnasterii">Anul nasterii <span style="color: #F00">*</span></label><br />
	<select name="anulnasterii" id="anulnasterii">
		<option value="" selected="selected">Alege anul nasterii...</option>
		<?php
		for($y=2010;$y>=1920;$y--) {
			echo '<option value="'.$y.'">'.$y.'</option>';
		}
		?>
	</select>
</p>
<p>
	<label>Adresa email <span style="color: #F00">*</span><br />
	<input type="text" size="25" name="email" /></label><small style="font-style:italic; color:#999">(exemplu: nume@domeniu.ro)</small><br />
</p>
<p>
	<label>Localitate <span style="color: #F00">*</span><br />
	<input type="text" size="25" name="localitate" /></label><small style="font-style:italic; color:#999">(exemplu: Mangalia)</small><br />
</p>
<p>
	<label>Judet <span style="color: #F00">*</span><br />
	<input type="text" size="25" name="judet" /></label><small style="font-style:italic; color:#999">(exemplu: Constanta)</small><br />
</p>
<p>
	<label>Parola<br />
	<input type="password" size="25" maxlength="10" name="password" /></label><br />
	<small style="color:#999">Maxim 10 caractere.</small>
</p>
<p>
	<label>Parola (confirmare)<br />
	<input type="password" size="25" maxlength="10" name="confirmpass" /></label><br />
	<small style="color:#999">Maxim 10 caractere.</small>
</p>
<hr size="1" />
<p>
	<label>Intrebare de verificare <span style="color: #F00">*</span><br />
	<?php echo $n1.' + '.$n2.' = ';?><input type="text" name="check" size="2" maxlength="2" /></label>
</p>
<div>
	<input type="hidden" name="1" value="<?php echo $n1;?>" />
	<input type="hidden" name="2" value="<?php echo $n2;?>" />
</div>
<p class="submit"><input type="submit" name="submit" value="Inregistrare" id="button" /> Daca ai deja un cont, poti sa <a href="login.php">intri</a> aici.</p>
</form>
