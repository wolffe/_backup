<?php
error_reporting(E_ALL); // was error_reporting(E_ALL);

$sitedomain = 'http://127.0.0.1:4001/www.pescuitulsportiv.ro/';

// Start the session and seed the random number generator
session_start();
srand();
if(isset($_SESSION['username'])) {
	$user = $_SESSION['username'];
	$username = $_SESSION['username'];
}

// settings file //
include('config.php');

// general settings
$org_title = "Clubul Pescarilor Sportivi din Dobrogea"; // this is the text to appear in the title bar of every page
$org_version = "2.0-beta"; // this is the current version of the site

// end of settings file

if(is_authed()) {
	$username = $_SESSION['username'];

	$sql = mysql_query("SELECT * FROM `user` WHERE username='$username' LIMIT 1");
	$row = mysql_fetch_array($sql);
	$cemail = $row['email'];
	$cavatar = $row['avatar'];
	$userid = $row['userid'];
	$me = $row['userid'];

	// GLOBALS
	$global_score = $row['score'];
	$global_userid = $row['userid'];
	$global_avatar = $row['avatar'];

	$global_option_updates = $row['option_updates'];
}
if(!is_authed()) {
	$global_option_updates = 15;
}
?>
