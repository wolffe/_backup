<?php include('includes/top.php');?>
<?php
$user = $_SESSION['username'];

user_logout();
?>
<div id="content">
<h2>Logout</h2>
<p>Ai iesit din cont.</p>
<meta http-equiv="refresh" content="0;url=http://www.pescuitulsportiv.ro" />
</div>
<?php include('includes/bottom.php');?>
