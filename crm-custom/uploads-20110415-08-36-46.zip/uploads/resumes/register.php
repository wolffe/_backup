<?php include('includes/top.php');?>
<h2>Inregistrare</h2>
<?php
if(!isset($_POST['submit'])) {
	// Show the form
	include 'includes/register_form.inc.php';
	include('includes/bottom.php');
	exit;
}
else {
	if($_POST['1'] + $_POST['2'] != $_POST['check']) {
		echo '<div class="error">Ai raspuns gresit la intrebarea de verificare.</div>';
		include('includes/bottom.php');
		exit;
}
	// Check if any of the fields are missing
	if(empty($_POST['username']) || empty($_POST['nume']) || empty($_POST['prenume']) || empty($_POST['anulnasterii']) || empty($_POST['password']) || empty($_POST['confirmpass']) || empty($_POST['email']) || empty($_POST['localitate']) || empty($_POST['judet'])) {
		// Reshow the form with an error
		$reg_error = '<div class="warning">Te rugam sa completezi toate campurile.</div>';
		include 'includes/register_form.inc.php';
		include('includes/bottom.php');
		exit;
	}

	if(!preg_match('/^[^@]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$/', $_POST['email'])) {
		$reg_error = '<div class="warning">Adresa de email nu este valida.</div>';
		include 'includes/register_form.inc.php';
		include('includes/bottom.php');
		exit;
	}
	// Check if the passwords match
	if($_POST['password'] != $_POST['confirmpass']) {
		// Reshow the form with an error
		$reg_error = '<div class="error">Parolele nu se potrivesc. Atentie la CAPS LOCK.</div>';
		include 'includes/register_form.inc.php';
		include('includes/bottom.php');
		exit;
	}

	$result = mysql_query("SELECT * FROM user",$database);

	while($myrow = mysql_fetch_array($result)) {
		if($_POST['username']==$myrow[1]) {
			echo '<div class="error">Acest utilizator exista deja in club. Alege alt nume de utilizator.</div>';
			include 'includes/register_form.inc.php';
			exit;
		}
	}

	// Everything is ok, register
	user_register($_POST['username'], $_POST['nume'], $_POST['prenume'], $_POST['anulnasterii'], $_POST['email'], $_POST['localitate'], $_POST['judet'], $_POST['password']);
	echo '<div class="success">Iti multumim pentru inscrierea in Clubul Pescarilor Sportivi din Dobrogea. Pentru a finaliza inscrierea si a activa contul da click pe linkul din email.</div>';
}

include('includes/bottom.php');
?>
