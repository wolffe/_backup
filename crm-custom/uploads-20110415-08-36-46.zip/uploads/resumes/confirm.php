<?php
include('includes/top.php');

if(isset($_GET['id'])) {
	$uid = $_GET['id'];
	$usql = "SELECT * FROM user WHERE userid = '$uid'";
	$uresult = mysql_query($usql);
	$uitem = mysql_fetch_array($uresult);
	$username = $uitem['username'];

	$sql = "UPDATE user SET confirmed ='1' WHERE userid = '$uid'";
	mysql_query($sql);
	echo 'Felicitari <strong>'.$username.'</strong>! Contul tau a fost activat!';
}
include('includes/bottom.php');
?>
