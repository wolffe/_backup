<?php include('includes/top.php');?>
<h2>Login</h2>
<?php
if(!isset($_POST['submit'])) {
	// Show the form
	if(!is_authed()) {
		include 'includes/login_form.inc.php';
		echo '</div>';
		include('includes/bottom.php');
		exit;
	}
	if(is_authed()) {

		// SCOR +1!
		$score = $global_score + 1;
		mysql_query("UPDATE user SET score = '$score' WHERE userid = '$global_userid'");	

		header('Location:index.php');
	}
}
elseif($_POST['username']!='')  {
	// Try and login with the given username & pass
	$result = user_login($_POST['username'], $_POST['password']);
	if ($result != 'Correct') {
	// Reshow the form with the error
		$login_error = '<div class="error">Utilizator sau parola incorecte, sau contul nu a fost activat.</div>';
		include 'includes/login_form.inc.php';
	}
	else {
		$user = $_SESSION['username'];

		$currentdate = date('Y-m-d');
		$result = mysql_query("SELECT * FROM user WHERE username='$user';");
		$row = mysql_fetch_array($result);
		mysql_query("UPDATE user SET date_logged='$currentdate' WHERE username='$user';");
		echo '
			<div class="info">
				Ai intrat in cont. Daca nu ai completat profilul, <a href="cpanel.php">fa-o acum</a>!<br />
				<a href="index.php">Mergi la prima pagina</a>.<br /><br />
				<strong>Ce poti sa faci?</strong>
				<ul>
					<li>Poti sa vizualizezi profilurile celorlalti membri.</li>
					<li>Poti sa adaugi, sa modifici sau sa vizualizezi evenimente.</li>
					<li>Poti sa discuti pe chat, public sau privat.</li>
					<li>Ai acces la cele mai recente noutati si anunturi.</li>
					<li><strong style="color:#f00">Nu uita sa apesi linkul Logout cand parasesti clubul!</strong></li>
			</div>';
		$a = $row['userid'];
		mysql_query("UPDATE user SET islogged='1' WHERE userid='$a' LIMIT 1;");
		header('Location:login.php');
	}
}
else {
	// Reshow the form with the error
	$login_error = '<div class="error">Utilizator sau parola incorecte.</div>';
	include 'includes/login_form.inc.php';
}
?>
<?php
include('includes/bottom.php');
?>
