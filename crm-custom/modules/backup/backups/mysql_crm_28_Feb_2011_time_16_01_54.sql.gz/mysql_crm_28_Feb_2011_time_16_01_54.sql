# MySQL backup created by phpMySQLAutoBackup - Version: 1.5.5
# 
# http://www.dwalker.co.uk/phpmysqlautobackup/
#
# Database: crm
# Domain name: 127.0.0.1:4001
# (c)2011 127.0.0.1:4001
#
# Backup START time: 16:01:52
# Backup END time: 16:01:52
# Backup Date: 28 Feb 2011
 
drop table if exists `attachments`; 
CREATE TABLE `attachments` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `attachment` text COLLATE latin1_general_ci NOT NULL,
  `itemid` int(11) NOT NULL,
  UNIQUE KEY `aid` (`aid`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci; 
insert into `attachments` (`aid`, `attachment`, `itemid`) values ('2', 'functions.php', '1'); 
insert into `attachments` (`aid`, `attachment`, `itemid`) values ('3', 'login_form.inc.php', '1'); 
insert into `attachments` (`aid`, `attachment`, `itemid`) values ('4', 'register_form.inc.php', '1'); 
insert into `attachments` (`aid`, `attachment`, `itemid`) values ('5', 'settings.php', '1'); 
insert into `attachments` (`aid`, `attachment`, `itemid`) values ('6', 'bottom.php', '0'); 
insert into `attachments` (`aid`, `attachment`, `itemid`) values ('7', 'functions.php', '6'); 
insert into `attachments` (`aid`, `attachment`, `itemid`) values ('8', 'login_form.inc.php', '7'); 
insert into `attachments` (`aid`, `attachment`, `itemid`) values ('9', 'register_form.inc.php', '8'); 
insert into `attachments` (`aid`, `attachment`, `itemid`) values ('10', 'settings.php', '9'); 
insert into `attachments` (`aid`, `attachment`, `itemid`) values ('11', 'atdsmttnyq4.jpg', '0'); 
insert into `attachments` (`aid`, `attachment`, `itemid`) values ('12', 'be56bdb4fd3bca5de4352c8.jpg', '11'); 
insert into `attachments` (`aid`, `attachment`, `itemid`) values ('13', 'atdsmttnyq4.jpg', '3220'); 
insert into `attachments` (`aid`, `attachment`, `itemid`) values ('14', 'be56bdb4fd3bca5de4352c8.jpg', '3220'); 
insert into `attachments` (`aid`, `attachment`, `itemid`) values ('15', '4ca1c0759d66aaframe.htm', '3221'); 
insert into `attachments` (`aid`, `attachment`, `itemid`) values ('16', '4ca1c0759dcfclogo.png', '3221'); 
insert into `attachments` (`aid`, `attachment`, `itemid`) values ('17', '4ca1c0759e3fbrss.gif', '3221'); 
insert into `attachments` (`aid`, `attachment`, `itemid`) values ('18', '4ca1c0759ff2agp_snake01.jpg', '3221'); 
insert into `attachments` (`aid`, `attachment`, `itemid`) values ('19', '4ca1c0a8ba30faframe.htm', '3222'); 
insert into `attachments` (`aid`, `attachment`, `itemid`) values ('20', '4ca1c0a8ba9c4logo.png', '3222'); 
insert into `attachments` (`aid`, `attachment`, `itemid`) values ('21', '4ca1c0a8bb1aerss.gif', '3222'); 
insert into `attachments` (`aid`, `attachment`, `itemid`) values ('22', '4ca1c0a8bb709gp_snake01.jpg', '3222'); 
insert into `attachments` (`aid`, `attachment`, `itemid`) values ('23', '4ca1c51b6e8a0pariazasigur.gif', '1'); 
insert into `attachments` (`aid`, `attachment`, `itemid`) values ('37', '', '3224'); 
insert into `attachments` (`aid`, `attachment`, `itemid`) values ('31', '', '3223'); 
 
drop table if exists `categories`; 
CREATE TABLE `categories` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `categoryname` text COLLATE latin1_general_ci NOT NULL,
  KEY `cid` (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci; 
insert into `categories` (`cid`, `categoryname`) values ('1', 'tinichigiu'); 
insert into `categories` (`cid`, `categoryname`) values ('3', 'programator'); 
insert into `categories` (`cid`, `categoryname`) values ('4', 'zugrav'); 
 
drop table if exists `items`; 
CREATE TABLE `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE latin1_general_ci NOT NULL,
  `lastname` text COLLATE latin1_general_ci NOT NULL,
  `birthdate` date NOT NULL,
  `email` text COLLATE latin1_general_ci NOT NULL,
  `address` text COLLATE latin1_general_ci NOT NULL,
  `address2` text COLLATE latin1_general_ci NOT NULL,
  `location` text COLLATE latin1_general_ci NOT NULL,
  `county` text COLLATE latin1_general_ci NOT NULL,
  `country` text COLLATE latin1_general_ci NOT NULL,
  `ci` text COLLATE latin1_general_ci NOT NULL,
  `phone` text COLLATE latin1_general_ci NOT NULL,
  `mobile` text COLLATE latin1_general_ci NOT NULL,
  `available` date NOT NULL,
  `diplomas` text COLLATE latin1_general_ci NOT NULL,
  `lastworkplace` text COLLATE latin1_general_ci NOT NULL,
  `driverlicense` text COLLATE latin1_general_ci NOT NULL,
  `category` tinyint(3) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `currentworkplace` text COLLATE latin1_general_ci NOT NULL,
  `description` text COLLATE latin1_general_ci NOT NULL,
  `notes` text COLLATE latin1_general_ci NOT NULL,
  `photo` text COLLATE latin1_general_ci NOT NULL,
  `resume` text COLLATE latin1_general_ci NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3241 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci; 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('1', 'Vasile', 'Lupu', '2009-01-01', 'cip_sb@hotmail.com', 'Bd. Tomis', '', 'Bucuresti', 'Dublin', '', '', '00993837377', '', '2010-01-09', 'faiantar, zugrav', 'bbc', '', '3', '2', '', '', '', '', '4c63f8a31f0cbnew-text-document.txt'); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('2', 'Vasile', 'Lupu', '2009-01-01', 'cip_sb@hotmail.com', 'Bd. Tomis', '', 'Bucuresti', '', '', '', '00993837377', '', '2010-01-09', 'faiantar, zugrav', 'bbc dar si cnn', '', '3', '1', '', 'baiat bun, muncitor, lenes, care stie tot si are 2 pisici', '', '4c63f8a31e3d619_blackout_poster.jpg', '4c63f8a31f0cbnew-text-document.txt'); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('7', 'Munteanu', 'Irina', '0000-00-00', 'pisi@pisici.org', 'Lalelelelele', '', 'Constanta', '', '', '', '0727465699', '039374749893', '0000-00-00', 'kjhdfs, fskdjf skdfsd, sdkjhfskjdhf', 'acasa', 'da, A, B', '1', '0', '', '', '', '4c934eb23509e773ac32483556e498ae90d4db7c604a7.jpg', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('8', 'Munteanu', 'Irina', '0000-00-00', 'pisi@pisici.org', 'Lalelelelele', '', 'Constanta', '', '', '', '0727465699', '039374749893', '0000-00-00', '\"kjhdfs', ' fskdjf skdfsd', '98', '56', '0', ' A', '', '', ' B\"', '1'); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('9', 'Munteanu', 'Irina', '0000-00-00', 'pisi@pisici.org', 'Lalelelelele', '', 'Constanta', '', '', '', '0727465699', '039374749893', '0000-00-00', '\"kjhdfs', ' fskdjf skdfsd', '98', '56', '0', ' A', '', '', ' B\"', '1'); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('10', 'Munteanu', 'Irina', '0000-00-00', 'pisi@pisici.org', 'Lalelelelele', '', 'Constanta', '', '', '', '0727465699', '039374749893', '0000-00-00', '\"kjhdfs', ' fskdjf skdfsd', '98', '56', '0', ' A', '', '', ' B\"', '1'); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('11', 'Munteanu', 'Irina', '0000-00-00', 'pisi@pisici.org', 'Lalelelelele', '', 'Constanta', '', '', '', '0727465699', '039374749893', '0000-00-00', '\"kjhdfs', ' fskdjf skdfsd', '98', '56', '0', ' A', '', '', ' B\"', '1'); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('21', 'Vasile', 'Lupu', '2009-01-01', 'cip_sb@hotmail.com', '\"Bd. Tomis\"', '', 'Bucuresti', '', '', '', '00993837377', '', '2010-01-09', '\"faiantar', ' zugrav\"', '', '0', '4', '2', '', '', '', '4c63f8a31e3d619_blackout_poster.jpg'); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('22', 'Vasile', 'Lupu', '2009-01-01', 'cip_sb@hotmail.com', '\"Bd. Tomis\"', '', 'Bucuresti', '', '', '', '00993837377', '', '2010-01-09', '\"faiantar', ' zugrav\"', '', '0', '3', '1', '', '', '', '4c63f8a31e3d619_blackout_poster.jpg'); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('27', 'Munteanu', 'Irina', '0000-00-00', 'pisi@pisici.org', 'Lalelelelele', '', 'Constanta', '', '', '', '0727465699', '039374749893', '0000-00-00', '\"kjhdfs', ' fskdjf skdfsd', '98', '56', '0', ' A', '', '', ' B\"', '1'); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('28', 'Munteanu', 'Irina', '0000-00-00', 'pisi@pisici.org', 'Lalelelelele', '', 'Constanta', '', '', '', '0727465699', '039374749893', '0000-00-00', '\"kjhdfs', ' fskdjf skdfsd', '98', '56', '0', ' A', '', '', ' B\"', '1'); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('29', 'Munteanu', 'Irina', '0000-00-00', 'pisi@pisici.org', 'Lalelelelele', '', 'Constanta', '', '', '', '0727465699', '039374749893', '0000-00-00', '\"kjhdfs', ' fskdjf skdfsd', '98', '56', '0', ' A', '', '', ' B\"', '1'); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('210', 'Munteanu', 'Irina', '0000-00-00', 'pisi@pisici.org', 'Lalelelelele', '', 'Constanta', '', '', '', '0727465699', '039374749893', '0000-00-00', '\"kjhdfs', ' fskdjf skdfsd', '98', '56', '0', ' A', '', '', ' B\"', '1'); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('211', 'Munteanu', 'Irina', '0000-00-00', 'pisi@pisici.org', 'Lalelelelele', '', 'Constanta', '', '', '', '0727465699', '039374749893', '0000-00-00', '\"kjhdfs', ' fskdjf skdfsd', '98', '56', '0', ' A', '', '', ' B\"', '1'); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('329', 'Munteanu', 'Irina', '0000-00-00', 'pisi@pisici.org', 'Lalelelelele', '', 'Constanta', '', '', '', '0727465699', '039374749893', '0000-00-00', '\"kjhdfs', ' fskdjf skdfsd', '98', '56', '0', ' A', '', '', ' B\"', '1'); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3210', 'Munteanu', 'Irina', '0000-00-00', 'pisi@pisici.org', 'Lalelelelele', '', 'Constanta', '', '', '', '0727465699', '039374749893', '0000-00-00', '\"kjhdfs', ' fskdjf skdfsd', '98', '56', '0', ' A', '', '', ' B\"', '1'); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3211', 'Munteanu', 'Irina', '0000-00-00', 'pisi@pisici.org', 'Lalelelelele', '', 'Constanta', '', '', '', '0727465699', '039374749893', '0000-00-00', '\"kjhdfs', ' fskdjf skdfsd', '98', '56', '0', ' A', '', '', ' B\"', '1'); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3212', 'sfg', 'sdfgsd', '2010-09-16', 'sdfgsdf', 'sfgs', '', 'sfdgs', '', '', '', 'sdfgsd', 'fsdfgsd', '2010-09-17', 'dfgs', 'dfgsd', 'gsdfgsdf', '3', '1', 'sfgsdf', '', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3213', 'kjkjk', 'jkj', '2010-09-07', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '3', '1', '', '', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3214', 'fdsa', 'fsdfs', '0000-00-00', '', 'dsff', '', 'sdf', '', '', '', '', '', '0000-00-00', '', '', '', '3', '1', '', '', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3215', 'fdsa', 'fsdfs', '0000-00-00', '', 'dsff', '', 'sdf', '', '', '', '', '', '0000-00-00', '', '', '', '3', '1', '', '', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3216', 'fdgsfg', 'sdfgsdf', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '3', '1', '', '', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3217', 'fdgsfg', 'sdfgsdf', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '3', '1', '', '', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3218', 'fdgsfg', 'sdfgsdf', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '3', '1', '', '', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3219', 'dasdas', 'dasdas', '0000-00-00', '', 'sdasda', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '3', '1', '', '', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3220', 'dasdas', 'dasdas', '0000-00-00', '', 'sdasda', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '3', '1', '', '', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3221', 'fsdaf', 'sadfasd', '0000-00-00', '', 'fasdfa', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '3', '1', '', '', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3222', 'fsdaf', 'sadfasd', '0000-00-00', '', 'fasdfa', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '3', '1', '', '', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3223', '111', '11', '2010-10-13', '', 'eqwe', '', 'qwe', '', '', 'eqweqwe', '', '', '0000-00-00', 'weqwqwe', 'qw', 'qwe', '3', '1', '', '', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3224', 'zzz', 'zzz', '0000-00-00', '', 'zzz', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '3', '1', '', '', '', 'a4cad8291809a8woodplanksclean0012_s.jpg', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3225', '123456', '123456', '2011-02-15', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '3', '2', '', '', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3226', 'Johnny', 'Cash', '2011-02-16', 'cip_sb@hotmail.com', 'Home street', 'Alley 1', 'Johnsontown', 'Down', '', '123464', '049587493573096', '9846593486', '2011-02-17', 'dkjhf, sdkjfh sdkjfh, skdjfh sdkjfh, d skjfs', 'home', 'yes', '1', '1', 'here', 'skjf gdkjf ksjf gkjfshg ksfdjhg ksdjf hgklf hlkdshf kgs hgkjs hdfkjg sdkjf ghskdjf gksj dfhgkjsfh gkjsd fhgksjdfgkjs dfkgjs fkg sdkf gskdf gsk fghksj dfhgkjs fhgkj shfdkgj sdfkjg sdkfj gslkdfj ghskjh', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3227', 'Johnny', 'Cash', '2011-02-16', 'cip_sb@hotmail.com', 'Home street', 'Alley 1', 'Johnsontown', 'Down', '', '123464', '049587493573096', '9846593486', '2011-02-17', 'dkjhf, sdkjfh sdkjfh, skdjfh sdkjfh, d skjfs', 'home', 'yes', '1', '1', 'here', 'skjf gdkjf ksjf gkjfshg ksfdjhg ksdjf hgklf hlkdshf kgs hgkjs hdfkjg sdkjf ghskdjf gksj dfhgkjsfh gkjsd fhgksjdfgkjs dfkgjs fkg sdkf gskdf gsk fghksj dfhgkjs fhgkj shfdkgj sdfkjg sdkfj gslkdfj ghskjh', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3228', 'Johnny', 'Cash', '2011-02-16', 'cip_sb@hotmail.com', 'Home street', 'Alley 1', 'Johnsontown', 'Down', '', '123464', '049587493573096', '9846593486', '2011-02-17', 'dkjhf, sdkjfh sdkjfh, skdjfh sdkjfh, d skjfs', 'home', 'yes', '1', '1', 'here', 'skjf gdkjf ksjf gkjfshg ksfdjhg ksdjf hgklf hlkdshf kgs hgkjs hdfkjg sdkjf ghskdjf gksj dfhgkjsfh gkjsd fhgksjdfgkjs dfkgjs fkg sdkf gskdf gsk fghksj dfhgkjs fhgkj shfdkgj sdfkjg sdkfj gslkdfj ghskjh', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3229', 'Johnny', 'Cash', '2011-02-16', 'cip_sb@hotmail.com', 'Home street', 'Alley 1', 'Johnsontown', 'Down', '', '123464', '049587493573096', '9846593486', '2011-02-17', 'dkjhf, sdkjfh sdkjfh, skdjfh sdkjfh, d skjfs', 'home', 'yes', '1', '1', 'here', 'skjf gdkjf ksjf gkjfshg ksfdjhg ksdjf hgklf hlkdshf kgs hgkjs hdfkjg sdkjf ghskdjf gksj dfhgkjsfh gkjsd fhgksjdfgkjs dfkgjs fkg sdkf gskdf gsk fghksj dfhgkjs fhgkj shfdkgj sdfkjg sdkfj gslkdfj ghskjh', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3230', 'Johnny', 'Cash', '2011-02-16', 'cip_sb@hotmail.com', 'Home street', 'Alley 1', 'Johnsontown', 'Down', '', '123464', '049587493573096', '9846593486', '2011-02-17', 'dkjhf, sdkjfh sdkjfh, skdjfh sdkjfh, d skjfs', 'home', 'yes', '1', '1', 'here', 'skjf gdkjf ksjf gkjfshg ksfdjhg ksdjf hgklf hlkdshf kgs hgkjs hdfkjg sdkjf ghskdjf gksj dfhgkjsfh gkjsd fhgksjdfgkjs dfkgjs fkg sdkf gskdf gsk fghksj dfhgkjs fhgkj shfdkgj sdfkjg sdkfj gslkdfj ghskjh', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3231', 'Johnny', 'Cash', '2011-02-16', 'cip_sb@hotmail.com', 'Home street', 'Alley 1', 'Johnsontown', 'Down', '', '123464', '049587493573096', '9846593486', '2011-02-17', 'dkjhf, sdkjfh sdkjfh, skdjfh sdkjfh, d skjfs', 'home', 'yes', '1', '1', 'here', 'skjf gdkjf ksjf gkjfshg ksfdjhg ksdjf hgklf hlkdshf kgs hgkjs hdfkjg sdkjf ghskdjf gksj dfhgkjsfh gkjsd fhgksjdfgkjs dfkgjs fkg sdkf gskdf gsk fghksj dfhgkjs fhgkj shfdkgj sdfkjg sdkfj gslkdfj ghskjh', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3232', 'Johnny', 'Cash', '2011-02-16', 'cip_sb@hotmail.com', 'Home street', 'Alley 1', 'Johnsontown', 'Down', '', '123464', '049587493573096', '9846593486', '2011-02-17', 'dkjhf, sdkjfh sdkjfh, skdjfh sdkjfh, d skjfs', 'home', 'yes', '1', '1', 'here', 'skjf gdkjf ksjf gkjfshg ksfdjhg ksdjf hgklf hlkdshf kgs hgkjs hdfkjg sdkjf ghskdjf gksj dfhgkjsfh gkjsd fhgksjdfgkjs dfkgjs fkg sdkf gskdf gsk fghksj dfhgkjs fhgkj shfdkgj sdfkjg sdkfj gslkdfj ghskjh', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3233', 'fsdfa', 'fadsfad', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '3', '1', '', '', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3234', 'fsdfa', 'fadsfad', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '3', '1', '', '', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3235', '6756', '75675', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '3', '1', '', '', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3236', '6756', '75675', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '3', '1', '', '', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3237', '6756', '75675', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '3', '1', '', '', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3238', 'bnbvnvvb', 'nvbnv', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '3', '1', '', '', '', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3239', 'fadsfa', 'adfasdf', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '3', '1', '', 'afadfasfasdfasd jdshkjds faldgfakjhsdgfajhds gfajshd gfakj fakjs dgfakj dgfakjh sdgfakjhs gdfajkhsd gjkah gjkas gfjka gfkjahs gfajkhd gf', 'a dd;jfadsl fhalk dfhalsk falsk akl hfakj hdfljashfka hsdghfl ashdflas h dfyaisdhfla dhfas dl ', '', ''); 
insert into `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3240', 'fadf', 'dsafadsfasdf', '0000-00-00', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '3', '1', '', 'dsa nfkjsdf askjd fbaskdj faksj hfalskd hfakjsd hfakjs hfak sdhfkashfkasdkfaskdfkas a k k d kdh faslkd jfal;sla sdjfla sjfal aj;ls jalsd als jfasljasl asl jasld jalsd alsd fa;lsjlas', 'dsa nfkjsdf askjd fbaskdj faksj hfalskd hfakjsd hfakjs hfak sdhfkashfkasdkfaskdfkas a k k d kdh faslkd jfal;sla sdjfla sjfal aj;ls jalsd als jfasljasl asl jasld jalsd alsd fa;lsjlasdsa nfkjsdf askjd fbaskdj faksj hfalskd hfakjsd hfakjs hfak sdhfkashfkasdkfaskdfkas a k k d kdh faslkd jfal;sla sdjfla sjfal aj;ls jalsd als jfasljasl asl jasld jalsd alsd fa;lsjlasdsa nfkjsdf askjd fbaskdj faksj hfalskd hfakjsd hfakjs hfak sdhfkashfkasdkfaskdfkas a k k d kdh faslkd jfal;sla sdjfla sjfal aj;ls jalsd als jfasljasl asl jasld jalsd alsd fa;lsjlas', '', ''); 
 
drop table if exists `phpmysqlautobackup`; 
CREATE TABLE `phpmysqlautobackup` (
  `id` int(11) NOT NULL,
  `version` varchar(6) COLLATE latin1_general_ci DEFAULT NULL,
  `time_last_run` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci; 
insert into `phpmysqlautobackup` (`id`, `version`, `time_last_run`) values ('1', '1.5.5', '1298905312'); 
 
drop table if exists `phpmysqlautobackup_log`; 
CREATE TABLE `phpmysqlautobackup_log` (
  `date` int(11) NOT NULL,
  `bytes` int(11) NOT NULL,
  `lines` int(11) NOT NULL,
  PRIMARY KEY (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci; 
insert into `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1298905225', '31327', '76'); 
 
drop table if exists `users`; 
CREATE TABLE `users` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `salt` varchar(3) COLLATE latin1_general_ci NOT NULL,
  `username` text COLLATE latin1_general_ci NOT NULL,
  `password` text COLLATE latin1_general_ci NOT NULL,
  `email` text COLLATE latin1_general_ci NOT NULL,
  `rank` int(11) NOT NULL,
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci; 
insert into `users` (`uid`, `salt`, `username`, `password`, `email`, `rank`) values ('1', 'abc', 'ciprian', '123456', 'cip_sb@yahoo.com', '0'); 
insert into `users` (`uid`, `salt`, `username`, `password`, `email`, `rank`) values ('7', '', 'vasile', 'vasile', '', '2'); 
