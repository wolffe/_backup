# MySQL backup version: 1.5.5
# 
# Database: rooie_crm
# Domain name: crm.roo.ie
# (c)2011 crm.roo.ie
#
# Backup START time: 11:08:09
# Backup END time: 11:08:09
# Backup Date: 09 Apr 2011
 
DROP TABLE IF EXISTS `attachments`; 
CREATE TABLE `attachments` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `attachment` text NOT NULL,
  `itemid` int(11) NOT NULL,
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM AUTO_INCREMENT=641 DEFAULT CHARSET=latin1; 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('1', '', '3239'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('2', '4ca1c70774d87page0001.jpg', '3237'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('3', '4ca1c72fadfbapage0001.jpg', '3236'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('6', '4ca2d4663ecc9page0001.jpg', '3240'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('7', '', '3241'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('8', '4ca2d65b53ea0page0001.jpg', '3241'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('9', '4ca2d65b54185page0002.jpg', '3241'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('10', '', '3242'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('11', '4ca2d8e628e20page0001.jpg', '3243'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('12', '4ca2db8b88573page0001.jpg', '3244'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('13', '', '3244'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('14', '', '3245'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('15', '4ca2e443ef7d0page0001.jpg', '3246'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('16', '4ca2e6cc57248page0001.jpg', '3247'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('17', '', '3248'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('18', '', '3248'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('19', '', '3249'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('20', '', '3249'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('21', '', '3250'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('22', '', '3251'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('23', '', '3252'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('24', '', '3248'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('25', '', '3252'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('26', '', '3253'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('27', '', '3254'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('28', '', '3255'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('29', '4ca2f6faea1b7page0001.jpg', '3256'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('30', '', '3230'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('31', '', '3229'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('32', '', '3228'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('33', '', '3232'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('34', '', '3231'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('35', '4ca2fcbe199d4page0001.jpg', '3227'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('36', '4ca2fcbe19d4dpage0002.jpg', '3227'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('37', '4ca2fcbe19eb6page0003.jpg', '3227'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('38', '4ca2fcbe19feapage0004.jpg', '3227'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('39', '', '3227'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('40', '4ca2fed7d8bb7page0001.jpg', '3226'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('41', '4ca2fed7d8ed3page0002.jpg', '3226'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('42', '4ca2ff9c84c09page0001.jpg', '3223'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('43', '', '3246'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('44', '4ca3028a7ffbapage0001.jpg', '3234'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('45', '4ca3028a802dfpage0002.jpg', '3234'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('46', '4ca303d19134fpage0001.jpg', '3235'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('47', '4ca303d191688page0002.jpg', '3235'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('48', '4ca303d1917f0page0003.jpg', '3235'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('49', '4ca304279a5f8page0001.jpg', '3238'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('50', '', '3237'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('51', '', '3236'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('52', '', '3244'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('53', '', '3241'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('54', '', '3234'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('55', '', '3242'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('56', '', '3247'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('57', '', '3249'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('58', '', '3250'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('59', '', '3249'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('60', '', '3251'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('61', '', '3240'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('62', '', '3248'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('63', '', '3253'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('64', '', '3253'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('65', '', '3254'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('66', '', '3255'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('67', '', '3231'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('68', '', '3256'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('69', '4ca423e28516apage0001.jpg', '3257'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('70', '', '3258'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('71', '', '3258'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('72', '4ca4282749e51page0001.jpg', '3259'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('73', '', '3260'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('74', '', '3261'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('75', '4ca42bbe3e5d1page0001.jpg', '3262'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('76', '', '3262'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('77', '', '3263'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('78', '', '3263'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('79', '4ca4613ec7d77page0001.jpg', '3264'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('80', '4ca4613ec7f17page0002.jpg', '3264'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('81', '', '3265'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('82', '4ca46d7f6796apage0001.jpg', '3226'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('83', '4ca46d7f6796apage0001.jpg', '3226'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('84', '4ca5834155c8epage0001.jpg', '3266'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('85', '4ca583cc1dab1page0001.jpg', '3234'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('86', '', '3267'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('223', '4cb7f09cb31bdpage0003.jpg', '3268'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('222', '4cb7f09cb305bpage0002.jpg', '3268'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('221', '4cb7f09cb2e84page0001.jpg', '3268'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('227', '4cb7f2db95ec3page0001.jpg', '3269'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('91', '4ca5890d7e5dapage0001.jpg', '3270'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('92', '', '3271'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('93', '', '3272'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('94', '', '3273'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('95', '4ca597896996apage0001.jpg', '3274'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('96', '4ca5978969af0page0002.jpg', '3274'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('97', '4ca5978969c0dpage0003.jpg', '3274'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('98', '', '3275'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('99', '4ca5996e27adapage0001.jpg', '3275'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('100', '4ca5996e27ecepage0002.jpg', '3275'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('101', '4ca59aa23071epage0001.jpg', '3276'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('102', '4ca59aa2308b9page0002.jpg', '3276'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('103', '4ca59aa230a0dpage0003.jpg', '3276'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('104', '4ca59aa230b63page0004.jpg', '3276'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('105', '4ca59aa230cadpage0005.jpg', '3276'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('106', '4ca59aa230de6page0006.jpg', '3276'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('107', '4ca59bcf88c42page0001.jpg', '3277'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('108', '4ca59bcf88dfcpage0002.jpg', '3277'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('109', '4caad374837efpage0001.jpg', '3241'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('110', '4caad374837efpage0001.jpg', '3241'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('111', '4caad3e04e1b4page0001.jpg', '3235'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('112', '4caad3e04e641page0002.jpg', '3235'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('113', '4caad3e04e641page0002.jpg', '3235'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('114', '4caad498d9f50page0001.jpg', '3262'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('115', '4caad498da159page0002.jpg', '3262'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('116', '4caad57079c2epage0001.jpg', '3248'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('117', '4caad5d12a2eapage0001.jpg', '3253'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('118', '4caad8db1bff7page0001.jpg', '3221'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('119', '4caad8db1c1e8page0002.jpg', '3221'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('120', '4caad8db1c1e8page0002.jpg', '3221'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('121', '4caad926f2325page0001.jpg', '3256'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('122', '4caad949bf902page0001.jpg', '3247'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('123', '4caad9cfb9a20page0001.jpg', '3244'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('124', '4caad9cfb9c12page0001.jpg', '3244'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('125', '4caad9ef31e68page0001.jpg', '3243'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('126', '4caad9ef32035page0002.jpg', '3243'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('127', '4caada1a4295epage0001.jpg', '3246'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('128', '4caada1a42b3dpage0002.jpg', '3246'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('129', '4caada9088798page0001.jpg', '3236'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('130', '4caada9088978page0001.jpg', '3236'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('131', '4caada9088ad3page0002.jpg', '3236'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('132', '4caadab830a85page0001.jpg', '3238'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('133', '4caadab830c48page0002.jpg', '3238'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('134', '4caadb0e0fd80page0001.jpg', '3252'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('155', '4cad970016cb5page0001.jpg', '3287'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('153', '4cad93db69949page0001.jpg', '3283'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('142', '', '3246'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('143', '', '3279'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('144', '4caaf9aa647a0page0001.jpg', '3280'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('145', '4cab155016367page0001.jpg', '3281'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('146', '4cab155016531page0002.jpg', '3281'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('147', '4cab19dcd93a7page0001.jpg', '3282'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('148', '4cab19dcd955fpage0002.jpg', '3282'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('149', '4cab19dcd96adpage0003.jpg', '3282'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('154', '4cad93db69b1dpage0002.jpg', '3283'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('156', '4cad97fdba1a0page0001.jpg', '3286'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('157', '4cad98368c073page0001.jpg', '3288'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('158', '4caeb3d4d3272page0001.jpg', '3289'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('159', '4caeb3d4d36a5page0002.jpg', '3289'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('160', '4caeb3d4d3824page0003.jpg', '3289'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('161', '4caeb3d4d3965page0004.jpg', '3289'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('162', '4caeb57056907page0001.jpg', '3290'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('163', '4caeb656c0c75page0001.jpg', '3291'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('164', '4caeb752de8d1page0001.jpg', '3292'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('165', '4caeb752ded1fpage0002.jpg', '3292'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('166', '4caeb85ea9612page0001.jpg', '3293'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('167', '4caeb958a68d2page0001.jpg', '3294'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('168', '4caeb958a6a82page0002.jpg', '3294'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('169', '4caeba775297cpage0001.jpg', '3295'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('170', '4caeba7752b10page0002.jpg', '3295'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('171', '4caeba7752c65page0003.jpg', '3295'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('172', '4caeba7752da9page0004.jpg', '3295'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('173', '4caee63b456ebpage0001.jpg', '3298'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('174', '4caee63b45b9fpage0002.jpg', '3298'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('175', '4caee7a87dfe1page0001.jpg', '3299'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('176', '4caee7a87e181page0002.jpg', '3299'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('177', '4caee7a87e2d7page0003.jpg', '3299'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('178', '4caee7a87e41bpage0004.jpg', '3299'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('179', '4caeea887e69epage0001.jpg', '3302'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('180', '4caeea887e69epage0001.jpg', '3302'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('181', '4cb2bb5151acdpage0001.jpg', '3305'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('182', '4cb2bb5153ecfpage0002.jpg', '3305'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('183', '4cb2bb5154067page0003.jpg', '3305'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('184', '4cb2bb51541b6page0004.jpg', '3305'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('185', '4cb2bc564f9a5page0001.jpg', '3306'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('186', '4cb2bc564fb52page0002.jpg', '3306'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('187', '4cb2bc564fd9apage0003.jpg', '3306'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('188', '4cb2bc564feeepage0004.jpg', '3306'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('189', '4cb2bc5650028page0005.jpg', '3306'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('190', '4cb2bc5650162page0006.jpg', '3306'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('191', '4cb2bc5650295page0007.jpg', '3306'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('192', '4cb2bd6c2d822page0001.jpg', '3307'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('193', '4cb2bd6c2d9d0page0002.jpg', '3307'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('194', '4cb2bd6c2db3apage0003.jpg', '3307'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('195', '4cb2bd6c2dc71page0004.jpg', '3307'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('196', '4cb2bebae75dfpage0001.jpg', '3308'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('197', '4cb2bebae778cpage0002.jpg', '3308'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('198', '4cb2bebae78d9page0003.jpg', '3308'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('199', '4cb2bebae7a12page0004.jpg', '3308'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('200', '4cb2bebae7b49page0005.jpg', '3308'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('201', '4cb2bebae7c86page0006.jpg', '3308'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('202', '4cb2bebae7dbbpage0007.jpg', '3308'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('203', '4cb2bebae7ef0page0008.jpg', '3308'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('204', '4cb2c04b49719page0001.jpg', '3309'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('205', '4cb2c144a578epage0001.jpg', '3310'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('206', '4cb2c144a592epage0002.jpg', '3310'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('207', '4cb2c20e2cd8apage0001.jpg', '3311'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('208', '4cb2c20e2cf41page0002.jpg', '3311'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('209', '4cb2c60601031page0001.jpg', '3314'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('210', '4cb2c6060121apage0002.jpg', '3314'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('211', '4cb7ef3d55750page0001.jpg', '3230'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('212', '4cb7ef3d55e08page0002.jpg', '3230'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('213', '4cb7ef3d55f8apage0003.jpg', '3230'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('214', '4cb7ef3d560c7page0004.jpg', '3230'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('215', '4cb7ef84e5d35page0001.jpg', '3231'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('216', '4cb7ef84e5f2fpage0002.jpg', '3231'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('217', '4cb7efd080ba6page0001.jpg', '3270'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('218', '4cb7efd080da8page0001.jpg', '3270'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('219', '4cb7efd080f02page0002.jpg', '3270'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('220', '4cb7efd081038page0003.jpg', '3270'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('224', '4cb7f09cb3305page0004.jpg', '3268'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('225', '4cb7f09cb3446page0005.jpg', '3268'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('226', '4cb7f09cb3580page0006.jpg', '3268'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('228', '4cb7f2db9609apage0002.jpg', '3269'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('229', '4cb801f3d8f8fpage0001.jpg', '3267'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('230', '4cb801f3d9160page0002.jpg', '3267'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('231', '4cb804c54e2dapage0001.jpg', '3240'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('232', '4cb806d429633page0001.jpg', '3242'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('233', '4cb806d42980epage0001.jpg', '3242'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('234', '4cbc0daa90343page0001.jpg', '3264'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('235', '4cbc0daa90527page0002.jpg', '3264'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('236', '4cbc0dd3b03a7page0001.jpg', '3263'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('237', '4cbc0dd3b0596page0002.jpg', '3263'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('238', '4cbc0ea9eeeb9page0001.jpg', '3245'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('239', '4cbc0ea9ef0a4page0002.jpg', '3245'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('240', '4cbc0ea9ef1f6page0003.jpg', '3245'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('241', '4cbc0ea9ef32apage0004.jpg', '3245'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('242', '4cbff5be287f4page0001.jpg', '3318'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('243', '4cbff7acd2ac7page0001.jpg', '3319'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('244', '4cbff7acd2c91page0002.jpg', '3319'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('245', '4cbff7f087683page0001.jpg', '3266'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('246', '4cbff9185f7b0page0001.jpg', '3320'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('247', '4cbff9185f96apage0002.jpg', '3320'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('248', '4cbff9185fae5page0003.jpg', '3320'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('249', '4cbff9185fc31page0004.jpg', '3320'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('250', '4cbff9185fd6fpage0005.jpg', '3320'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('251', '4cbff9185feaapage0006.jpg', '3320'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('252', '4cbff9185ffe3page0007.jpg', '3320'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('253', '4cbff9186012dpage0008.jpg', '3320'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('254', '4cbff9186026apage0009.jpg', '3320'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('255', '4cbff918603a8page0010.jpg', '3320'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('256', '4cbff918604dfpage0011.jpg', '3320'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('257', '4cbff9186061bpage0012.jpg', '3320'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('258', '4cbff9186074fpage0013.jpg', '3320'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('259', '4cc127ee1a802page0001.jpg', '3322'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('260', '4cc127ee1a9c2page0002.jpg', '3322'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('261', '4cc1290ccbf90page0001.jpg', '3323'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('262', '4cc12a1a23bddpage0002.jpg', '3324'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('263', '4cc12a1a23d7cpage0003.jpg', '3324'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('264', '4cc12ac362526page0001.jpg', '3325'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('265', '4cc12ba8d260apage0001.jpg', '3326'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('266', '4cc12c6ab66bbpage0001.jpg', '3327'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('267', '4cc12e842ff43page0001.jpg', '3329'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('268', '4cc1330cb1f29page0001.jpg', '3330'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('269', '4cc133c7ed5c2page0001.jpg', '3331'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('270', '4cc1367d55409page0001.jpg', '3333'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('271', '4cc1372bde8b4page0001.jpg', '3334'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('272', '4cc1372bdea53page0002.jpg', '3334'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('273', '4cc1384322809page0001.jpg', '3335'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('274', '4cc1395f3ef63page0001.jpg', '3336'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('275', '4cc13ad1ea144page0001.jpg', '3337'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('276', '4cc13ad1ea2f7page0002.jpg', '3337'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('277', '4cc13ad1ea456page0003.jpg', '3337'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('278', '4cc13ad1ea5a3page0004.jpg', '3337'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('279', '4cc13ad1ea6f5page0005.jpg', '3337'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('280', '4cc13ad1ea843page0006.jpg', '3337'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('281', '4cc13c20d145epage0001.jpg', '3338'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('282', '4cc13d256cf46page0001.jpg', '3339'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('283', '4cc152d6daba6page0001.jpg', '3341'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('284', '4cc7cf6fae996page0001.jpg', '3344'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('285', '4cc7cf6faf0ecpage0002.jpg', '3344'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('286', '4cc7d12139ff4page0001.jpg', '3346'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('287', '4cc7d22276b39page0001.jpg', '3347'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('288', '4cc7d22276cd7page0002.jpg', '3347'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('289', '4cc7d3293a948page0001.jpg', '3348'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('290', '4cc7d7b019ca2page0001.jpg', '3349'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('291', '4cc90e18e9ba5page0001.jpg', '3350'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('292', '4cc943772c04bpage0001.jpg', '3351'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('293', '4cd3ad9bbf1f4page0001.jpg', '3353'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('294', '4cd3ae7c16460page0001.jpg', '3354'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('295', '4cd3ae7c1661bpage0002.jpg', '3354'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('296', '4cd3af8601d54page0001.jpg', '3355'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('297', '4cd3b067cbb39page0001.jpg', '3356'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('298', '4cd3b16909e5apage0001.jpg', '3357'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('299', '4cd3b26ece93apage0001.jpg', '3358'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('300', '4cd3b26ecead7page0002.jpg', '3358'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('301', '4cd3b26ecec07page0003.jpg', '3358'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('302', '4cd7b90915685page0001.jpg', '3386'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('303', '4cd7e24e5a5b8page0001.jpg', '3390'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('304', '4cd7e24e5ae5epage0002.jpg', '3390'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('305', '4cd91a8f7f572page0001.jpg', '3391'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('306', '4cd91edb42262page0001.jpg', '3394'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('307', '4cd91edb42447page0002.jpg', '3394'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('308', '4cd91edb425a2page0003.jpg', '3394'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('309', '4cd91faf1c7cfpage0001.jpg', '3395'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('310', '4cd91faf1c963page0002.jpg', '3395'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('311', '4cd91faf1ca93page0003.jpg', '3395'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('312', '4cd9205d91e68page0001.jpg', '3396'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('313', '4cd9214641125page0001.jpg', '3397'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('314', '4cd92146412e5page0001.jpg', '3397'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('315', '4cd9221697644page0001.jpg', '3398'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('316', '4cd922fa713b8page0001.jpg', '3399'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('317', '4cd922fa7153dpage0002.jpg', '3399'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('318', '4cd922fa7167apage0003.jpg', '3399'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('319', '4cd925daad581page0001.jpg', '3400'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('320', '4cd925daad78apage0002.jpg', '3400'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('321', '4cd92924a34b1page0001.jpg', '3401'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('322', '4cd92924a36a8page0002.jpg', '3401'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('323', '4cd92924a3801page0003.jpg', '3401'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('324', '4cd92da474711page0001.jpg', '3402'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('327', '4cd9302b6bf88page0001.jpg', '3404'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('326', '4cd92ed66f3cbpage0001.jpg', '3403'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('328', '4cd931beb15b8page0001.jpg', '3405'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('329', '4cd931beb177apage0002.jpg', '3405'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('330', '4cd9347ad67a3page0001.jpg', '3406'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('331', '4cd9347ad6974page0002.jpg', '3406'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('332', '4cd9347ad6ad1page0003.jpg', '3406'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('333', '4cd9347ad6c21page0004.jpg', '3406'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('334', '4cda5536ad5ebpage0001.jpg', '3407'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('335', '4cda5536ad7cdpage0002.jpg', '3407'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('336', '4cda569f63132page0001.jpg', '3408'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('337', '4cdbc4f193fbbpage0001.jpg', '3409'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('338', '4cdbc7bb22318page0001.jpg', '3411'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('339', '4cdbc7bb22502page0001.jpg', '3411'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('340', '4cdbc90d82f58page0001.jpg', '3412'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('341', '4cdbc90d8311cpage0001.jpg', '3412'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('342', '4cdbd511eb93cpage0001.jpg', '3414'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('343', '4cdbd511ebae3page0002.jpg', '3414'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('344', '4cdbdd04310edpage0001.jpg', '3415'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('345', '4cdbdd04312bcpage0002.jpg', '3415'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('346', '4cdbdeda67d39page0001.jpg', '3416'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('347', '4cdbdeda67efapage0002.jpg', '3416'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('348', '4cdbdfcdc12fbpage0001.jpg', '3417'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('349', '4cdbdfcdc14ddpage0002.jpg', '3417'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('350', '4cdbe1aee51a8page0001.jpg', '3419'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('351', '4cdbe1aee537apage0002.jpg', '3419'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('352', '4cdbe2a53c906page0001.jpg', '3420'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('353', '4cdbe2a53cacbpage0002.jpg', '3420'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('354', '4cdbe336a33abpage0001.jpg', '3421'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('355', '4cdbe336a355cpage0002.jpg', '3421'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('356', '4cdbe336a36aepage0003.jpg', '3421'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('357', '4cdbe4bd7c676page0001.jpg', '3422'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('358', '4cdbe4bd7c83epage0002.jpg', '3422'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('359', '4cee1791926bepage0001.jpg', '3418'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('360', '4cee179193f90page0002.jpg', '3418'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('361', '4cee17ce22560page0001.jpg', '3423'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('362', '4cee17ce22726page0002.jpg', '3423'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('363', '4cee196a53ea3page0001.jpg', '3425'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('364', '4cee196a55b3fpage0002.jpg', '3425'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('365', '4cee1a0cef221page0001.jpg', '3426'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('366', '4cee1a0cef3a3page0002.jpg', '3426'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('367', '4cee1d1f0e3a3page0001.jpg', '3428'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('368', '4cee1edc32e48page0001.jpg', '3429'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('369', '4cee1edc32fd8page0002.jpg', '3429'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('370', '4cee202dbdf36page0001.jpg', '3430'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('371', '4cee202dbe102page0002.jpg', '3430'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('372', '4cee25b64664dpage0001.jpg', '3432'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('373', '4cee2726abb44page0001.jpg', '3433'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('374', '4cee2726abce5page0002.jpg', '3433'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('375', '4cee4beb0b2fbpage0001.jpg', '3434'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('376', '4cee4beb0b4c3page0002.jpg', '3434'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('377', '4cee4beb0b61bpage0003.jpg', '3434'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('378', '4cee4beb0b762page0004.jpg', '3434'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('379', '4cee4d8de69b8page0001.jpg', '3436'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('380', '4cee4d8de6b85page0002.jpg', '3436'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('381', '4cee4f2ee0d02page0001.jpg', '3437'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('382', '4cee59d7e9d9cpage0001.jpg', '3440'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('383', '4cee59d7e9f5bpage0002.jpg', '3440'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('384', '4cee5a9c4bea2page0001.jpg', '3441'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('385', '4cee5a9c4c049page0002.jpg', '3441'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('386', '4cee5a9c4c1abpage0003.jpg', '3441'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('387', '4cee5a9c4c2fepage0004.jpg', '3441'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('388', '4cee5c2e1f976page0001.jpg', '3443'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('389', '4cf38098e2688page0001.jpg', '3444'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('390', '4cf38098e2826page0002.jpg', '3444'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('391', '4cf4a91ade68fpage0001.jpg', '3445'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('392', '4cf4a91ade884page0002.jpg', '3445'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('393', '4cf4aa1a133a0page0001.jpg', '3446'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('394', '4cf4aa1a13550page0002.jpg', '3446'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('395', '4cf4aaf7f35fdpage0001.jpg', '3447'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('396', '4cf4aaf7f37b0page0002.jpg', '3447'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('397', '4cf4aaf7f38ddpage0003.jpg', '3447'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('398', '4cf4aaf7f39f6page0004.jpg', '3447'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('399', '4cf4acba2f56bpage0001.jpg', '3448'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('400', '4cf4acba2f700page0002.jpg', '3448'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('401', '4cf4ada7613fdpage0001.jpg', '3449'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('402', '4cf4af5402a47page0001.jpg', '3450'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('403', '4cf4af5402c06page0002.jpg', '3450'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('404', '4cf4af5402d65page0003.jpg', '3450'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('405', '4cf4b176e68a0page0001.jpg', '3451'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('406', '4cf4b176e6a60page0002.jpg', '3451'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('407', '4cf4b6d53638dpage0001.jpg', '3452'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('408', '4cf4b6d536524page0002.jpg', '3452'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('409', '4cf4c0b1acccdpage0001.jpg', '3453'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('410', '4d05f2d66149cpage0001.jpg', '3454'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('411', '4d05f39a851c2page0001.jpg', '3455'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('412', '4d05f39a85c77page0002.jpg', '3455'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('413', '4d05f528a4a96page0001.jpg', '3408'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('414', '4d05f528a4c8epage0002.jpg', '3408'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('415', '4d05f528a4df9page0003.jpg', '3408'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('416', '4d05f528a4f57page0004.jpg', '3408'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('417', '4d05f55d0a3a8page0001.jpg', '3391'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('418', '4d05f68a2019fpage0001.jpg', '3456'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('419', '4d05fe6e070cepage0001.jpg', '3457'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('420', '4d05fe6e070cepage0001.jpg', '3457'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('421', '4d0600775cfe9page0001.jpg', '3458'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('422', '4d0600775d1cbpage0002.jpg', '3458'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('423', '4d0600c9ef06dpage0001.jpg', '3457'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('424', '4d0600c9ef27apage0002.jpg', '3457'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('425', '4d06023e0a1bapage0001.jpg', '3459'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('426', '4d06023e0a382page0002.jpg', '3459'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('427', '4d22f14075561page0001.jpg', '3460'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('428', '4d22f249f2017page0001.jpg', '3461'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('429', '4d22f249f21ebpage0002.jpg', '3461'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('430', '4d22f249f21ebpage0002.jpg', '3461'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('431', '4d22f429c728fpage0001.jpg', '3462'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('432', '4d22f429c7480page0002.jpg', '3462'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('433', '4d22f429c75dbpage0003.jpg', '3462'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('434', '4d24268e8de82muresan-petrica+david-toma.tif', '3463'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('435', '4d242743df0b8page0001.jpg', '3464'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('436', '4d2427d52556fpage0001.jpg', '3465'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('437', '4d2429e050b9apage0001.jpg', '3467'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('438', '4d2429e050d65page0002.jpg', '3467'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('439', '4d242aad0deb2page0001.jpg', '3468'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('440', '4d242aad0e089page0002.jpg', '3468'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('441', '4d242aad0e089page0002.jpg', '3468'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('442', '4d2434c90c7b4page0001.jpg', '3469'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('443', '4d2434c90c988page0001.jpg', '3469'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('444', '4d2437a3054f6page0001.jpg', '3470'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('445', '4d2437a30568fpage0002.jpg', '3470'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('446', '4d2437a3057d7page0003.jpg', '3470'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('447', '4d243ce7d081bpage0001.jpg', '3471'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('448', '4d243ce7d0a32page0001.jpg', '3471'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('449', '4d243d9d685cbpage0001.jpg', '3472'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('450', '4d243d9d68762page0001.jpg', '3472'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('451', '4d243e380bbf7page0001.jpg', '3473'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('452', '4d258154412a7page0001.jpg', '3396'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('453', '4d2581a686281page0001.jpg', '3390'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('454', '4d2581dbb95a3page0001.jpg', '3339'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('455', '4d2581fee0f74page0001.jpg', '3327'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('456', '4d2581fee0f74page0001.jpg', '3327'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('457', '4d258293b6260page0001.jpg', '3345'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('458', '4d258293b6450page0002.jpg', '3345'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('459', '4d258293b65a7page0003.jpg', '3345'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('460', '4d258293b66ebpage0004.jpg', '3345'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('461', '4d2582b70f9b0page0001.jpg', '3352'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('462', '4d2582b70fb89page0002.jpg', '3352'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('463', '4d2582fcce179page0001.jpg', '3438'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('464', '4d2583fb3fc57page0001.jpg', '3413'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('465', '4d2583fb3fe35page0002.jpg', '3413'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('466', '4d2583fb3ff94page0003.jpg', '3413'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('467', '4d2583fb400ddpage0004.jpg', '3413'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('468', '4d258444a2d53page0001.jpg', '3427'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('469', '4d258444a2f3epage0002.jpg', '3427'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('470', '4d25846f2c590page0001.jpg', '3409'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('471', '4d25848f59c3epage0001.jpg', '3439'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('472', '4d25848f59e2apage0002.jpg', '3439'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('473', '4d2584b8b41f5page0001.jpg', '3414'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('474', '4d2584b8b43c5page0002.jpg', '3414'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('475', '4d258544d7d23page0001.jpg', '3343'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('476', '4d258544d7f2dpage0002.jpg', '3343'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('477', '4d258544d80b7page0003.jpg', '3343'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('478', '4d258544d820dpage0004.jpg', '3343'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('479', '4d2585673dcb8page0001.jpg', '3323'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('480', '4d258587dfd35page0001.jpg', '3389'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('481', '4d258587dff09page0002.jpg', '3389'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('482', '4d2585ce36928page0001.jpg', '3333'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('483', '4d2585efbcbb3page0001.jpg', '3310'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('484', '4d258612e79f9page0001.jpg', '3332'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('485', '4d258612e7bd4page0002.jpg', '3332'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('486', '4d2586787f7fapage0001.jpg', '3294'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('487', '4d2586787fa04page0002.jpg', '3294'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('488', '4d25869fd4081page0001.jpg', '3298'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('489', '4d25869fd4261page0002.jpg', '3298'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('490', '4d2586c78384cpage0001.jpg', '3387'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('491', '4d2586c783a2dpage0002.jpg', '3387'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('492', '4d2586c783b86page0003.jpg', '3387'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('493', '4d2586c783cccpage0004.jpg', '3387'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('494', '4d25870cb52d4page0001.jpg', '3342'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('495', '4d25870cb54b2page0002.jpg', '3342'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('496', '4d25870cb5610page0003.jpg', '3342'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('497', '4d25872b3d41fpage0001.jpg', '3346'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('498', '4d2587514109bpage0001.jpg', '3348'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('499', '4d2587be77f83page0001.jpg', '3326'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('500', '4d25890ce546bpage0001.jpg', '3347'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('501', '4d25890ce563dpage0002.jpg', '3347'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('502', '4d258935609a6page0001.jpg', '3334'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('503', '4d25893560c0apage0002.jpg', '3334'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('504', '4d25896cb3089page0001.jpg', '3350'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('505', '4d258c2ee5212page0001.jpg', '3312'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('506', '4d258c2ee5cf5page0002.jpg', '3312'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('507', '4d258c2ee5ea0page0003.jpg', '3312'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('508', '4d258c2ee606epage0004.jpg', '3312'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('509', '4d258c5517668page0001.jpg', '3331'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('510', '4d258cd8ebd2bpage0001.jpg', '3297'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('511', '4d258cd8ebf41page0002.jpg', '3297'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('512', '4d258d62c6fd1page0001.jpg', '3296'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('513', '4d258d62c71eapage0002.jpg', '3296'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('514', '4d2595fad454apage0001.jpg', '3288'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('515', '4d2595fad4720page0002.jpg', '3288'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('516', '4d25965ea8ebdpage0001.jpg', '3287'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('517', '4d259684a7049page0001.jpg', '3265'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('518', '4d259684a722apage0002.jpg', '3265'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('519', '4d2aa5d1307ebpage0001.jpg', '3474'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('520', '4d2aa6642a3a3page0001.jpg', '3475'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('521', '4d2aa6642a584page0002.jpg', '3475'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('522', '4d2aa7f888572page0001.jpg', '3476'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('523', '4d2aa7f88873dpage0002.jpg', '3476'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('524', '4d2aa89a55d77page0001.jpg', '3477'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('525', '4d2aa89a55f1cpage0002.jpg', '3477'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('526', '4d2aa92a951a7page0001.jpg', '3478'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('527', '4d2aa92a95369page0002.jpg', '3478'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('528', '4d2aa97cadbf4page0001.jpg', '3324'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('529', '4d2aa97cadddepage0002.jpg', '3324'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('530', '4d2aaa3f588fdpage0001.jpg', '3479'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('531', '4d2aaa3f58af6page0002.jpg', '3479'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('532', '4d2aaa3f58c5dpage0003.jpg', '3479'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('533', '4d2aaacd0e076page0001.jpg', '3480'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('534', '4d2aaacd0e282page0002.jpg', '3480'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('535', '4d2aaacd0e3b3page0003.jpg', '3480'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('536', '4d2aaacd0e4ccpage0004.jpg', '3480'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('537', '4d2aab9c60d7epage0001.jpg', '3481'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('538', '4d2aab9c60f2bpage0002.jpg', '3481'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('539', '4d2aac29b3a58page0001.jpg', '3482'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('540', '4d2aac29b3c2cpage0002.jpg', '3482'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('541', '4d2aac29b3d7fpage0003.jpg', '3482'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('542', '4d2aad65ba1b0page0001.jpg', '3483'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('543', '4d2aad65ba37bpage0002.jpg', '3483'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('544', '4d2ab4196d8bepage0001.jpg', '3484'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('545', '4d2ab4196da51page0002.jpg', '3484'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('546', '4d2ab48e203abpage0001.jpg', '3485'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('547', '4d2ab510ca0a7page0001.jpg', '3486'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('548', '4d2ab510ca28dpage0002.jpg', '3486'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('549', '4d2ab510ca3eepage0003.jpg', '3486'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('550', '4d2ab510ca5bepage0004.jpg', '3486'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('551', '4d2ab583d3eccpage0001.jpg', '3487'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('552', '4d2ab583d4097page0002.jpg', '3487'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('553', '4d2ab583d41f2page0003.jpg', '3487'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('554', '4d2ab583d433apage0004.jpg', '3487'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('555', '4d2ab60f5a16apage0001.jpg', '3488'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('556', '4d2ab60f5a343page0002.jpg', '3488'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('557', '4d2ab60f5a4abpage0003.jpg', '3488'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('558', '4d2ab60f5a5f5page0004.jpg', '3488'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('559', '4d2ab60f5a736page0005.jpg', '3488'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('560', '4d2ab60f5a86dpage0006.jpg', '3488'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('561', '4d2ab6b468d7apage0001.jpg', '3489'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('562', '4d2ab6b468f2dpage0002.jpg', '3489'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('563', '4d2ab6b46907fpage0003.jpg', '3489'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('564', '4d2ab6b4691bfpage0004.jpg', '3489'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('565', '4d2ab74ca9ba7page0001.jpg', '3490'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('566', '4d2ab74ca9d5cpage0002.jpg', '3490'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('567', '4d2ab7d0b1779page0001.jpg', '3491'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('568', '4d2ab7d0b1944page0002.jpg', '3491'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('569', '4d2ab7d0b1a85page0003.jpg', '3491'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('570', '4d2ab7d0b1b9dpage0004.jpg', '3491'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('571', '4d2ab7d0b1cabpage0005.jpg', '3491'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('572', '4d2ab8a8b8124page0001.jpg', '3492'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('573', '4d2ab8a8b82fbpage0002.jpg', '3492'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('574', '4d2ab92edbdb0page0001.jpg', '3493'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('575', '4d2ab92edbfc5page0002.jpg', '3493'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('576', '4d2ab92edc125page0003.jpg', '3493'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('577', '4d2ab98fcc985page0001.jpg', '3494'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('578', '4d2ab98fccb3epage0002.jpg', '3494'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('579', '4d2aba1302c45page0001.jpg', '3495'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('580', '4d2aba59896d1page0001.jpg', '3496'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('581', '4d2ad2339177epage0001.jpg', '3455'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('582', '4d2ad233922c9page0002.jpg', '3455'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('583', '4d2ad2339246cpage0003.jpg', '3455'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('584', '4d38094c6e56fpage0001.jpg', '3492'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('585', '4d38094c6f3d5page0002.jpg', '3492'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('586', '4d380a7c7e9a3page0001.jpg', '3497'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('587', '4d380a7c7eb87page0002.jpg', '3497'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('588', '4d380bf991446ionescu-doru--2.tif', '3498'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('589', '4d380ca1c7bc0page0001.jpg', '3499'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('590', '4d380ca1c7dc1page0002.jpg', '3499'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('591', '4d3d21c08959cpage0001.jpg', '3500'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('592', '4d3d2325760dfpage0001.jpg', '3501'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('593', '4d3d232576288page0002.jpg', '3501'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('594', '4d3d23e329a8apage0001.jpg', '3502'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('595', '4d3d57972218cpage0001.jpg', '3503'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('596', '4d3d57972234dpage0002.jpg', '3503'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('597', '4d3d588c2b514page0001.jpg', '3504'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('598', '4d3d588c2b6e8page0002.jpg', '3504'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('599', '4d3d59f7d4c96page0001.jpg', '3505'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('600', '4d3d59f7d4e5apage0002.jpg', '3505'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('601', '4d3d5a618bf97page0001.jpg', '3506'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('602', '4d3d5a618c16apage0002.jpg', '3506'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('603', '4d3d61178f6f4page0001.jpg', '3507'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('604', '4d3d61fb584a8page0001.jpg', '3508'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('605', '4d3d61fb5864epage0002.jpg', '3508'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('606', '4d3d61fb587aapage0003.jpg', '3508'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('607', '4d4f9b2d21028ionescu-doru--2.tif', '3509'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('608', '4d4f9b2d21028ionescu-doru--2.tif', '3509'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('609', '4d4f9df82e7c5page0001.jpg', '3511'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('610', '4d4fa02a34bbfpage0001.jpg', '3513'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('611', '4d4fa02a34d4apage0002.jpg', '3513'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('612', '4d4fa13e9a366page0001.jpg', '3514'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('613', '4d4fa13e9a516page0002.jpg', '3514'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('614', '4d4fa13e9a67bpage0003.jpg', '3514'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('615', '4d4fa13e9a7cepage0004.jpg', '3514'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('616', '4d4fa3d692049page0001.jpg', '3516'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('617', '4d4ff1bfe099cpage0001.jpg', '3510'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('618', '4d4ff1e53256dpage0001.jpg', '3512'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('619', '4d4ff1ff8dda9page0001.jpg', '3498'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('620', '4d4ff280b62a4page0001.jpg', '3500'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('621', '4d4ff58243590page0001.jpg', '3517'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('622', '4d54e03555e32page0001.jpg', '3518'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('623', '4d54e03556d24page0002.jpg', '3518'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('624', '4d54e0ee052f8page0001.jpg', '3519'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('625', '4d54e0ee054bdpage0002.jpg', '3519'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('626', '4d54e17463ce6page0001.jpg', '3520'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('627', '4d54e2079aa86page0001.jpg', '3521'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('628', '4d54e2079ac5bpage0002.jpg', '3521'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('629', '4d54e2079adc8page0003.jpg', '3521'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('630', '4d54e2af66ee0page0001.jpg', '3522'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('631', '4d54e2af670a2page0002.jpg', '3522'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('632', '4d54e2af67200page0003.jpg', '3522'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('633', '4d54e2af67356page0004.jpg', '3522'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('634', '4d54e2af674a2page0005.jpg', '3522'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('635', '4d54e321bace1page0001.jpg', '3523'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('636', '4d54e452aa624page0001.jpg', '3524'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('637', '4d54e452aa7cfpage0002.jpg', '3524'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('638', '4d54e452aa902page0003.jpg', '3524'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('639', '4d54e4ef32954page0001.jpg', '3525'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('640', '4d54e76a39fadpage0001.jpg', '3526'); 
 
DROP TABLE IF EXISTS `categories`; 
CREATE TABLE `categories` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `categoryname` text COLLATE latin1_general_ci NOT NULL,
  KEY `cid` (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci; 
INSERT INTO `categories` (`cid`, `categoryname`) values ('3', 'programmer'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('4', 'painter'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('7', 'electrician'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('8', 'mechanic'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('9', 'metal locksmith'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('11', 'driver'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('12', 'locksmiths'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('13', 'welder'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('15', 'carpenter'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('16', 'heat insulator'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('17', 'smelter'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('18', 'blacksmith concreter'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('21', 'drywall mechanic'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('22', 'bricklayer '); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('24', 'economist'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('27', 'lawyer'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('29', 'builder'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('30', 'engineer'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('31', 'electromechanical'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('33', 'woodworking operator'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('35', 'labourer'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('36', 'technician'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('48', 'locksmith'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('42', 'shipbuilding locksmith'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('43', 'locksmith fitter aggregate'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('44', 'plumber'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('46', 'electronist'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('47', 'waterproof insulator'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('49', 'sandblaster'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('50', 'craner'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('51', 'machinist tools'); 
 
DROP TABLE IF EXISTS `items`; 
CREATE TABLE `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE latin1_general_ci NOT NULL,
  `lastname` text COLLATE latin1_general_ci NOT NULL,
  `birthdate` date NOT NULL,
  `email` text COLLATE latin1_general_ci NOT NULL,
  `address` text COLLATE latin1_general_ci NOT NULL,
  `address2` text COLLATE latin1_general_ci NOT NULL,
  `location` text COLLATE latin1_general_ci NOT NULL,
  `county` text COLLATE latin1_general_ci NOT NULL,
  `country` text COLLATE latin1_general_ci NOT NULL,
  `ci` text COLLATE latin1_general_ci NOT NULL,
  `phone` text COLLATE latin1_general_ci NOT NULL,
  `mobile` text COLLATE latin1_general_ci NOT NULL,
  `available` date NOT NULL,
  `linkedin` text COLLATE latin1_general_ci NOT NULL,
  `diplomas` text COLLATE latin1_general_ci NOT NULL,
  `lastworkplace` text COLLATE latin1_general_ci NOT NULL,
  `driverlicense` text COLLATE latin1_general_ci NOT NULL,
  `category` tinyint(3) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `currentworkplace` text COLLATE latin1_general_ci NOT NULL,
  `description` text COLLATE latin1_general_ci NOT NULL,
  `notes` text COLLATE latin1_general_ci NOT NULL,
  `photo` text COLLATE latin1_general_ci NOT NULL,
  `resume` text COLLATE latin1_general_ci NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3532 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci; 
INSERT INTO `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `linkedin`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3528', 'Jared', 'Eckhart', '1969-02-10', 'jared_1087@gmail.com', '26 Last House on the Left', '', 'London', '', '', '0012311', '0727465699', '057 8674315', '2011-02-28', '', 'programmer', 'Microsoft Corp.', 'No', '3', '2', 'M.I.T.', '', '', 'a4d60457a1ce67alex-actor-headshots-theater-model-eugene-oregon-2.jpg', ''); 
INSERT INTO `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `linkedin`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3529', 'Patti', 'Smith', '1969-02-12', 'patti@worldrecords.org', 'Phoenix Rd.', '', 'Atlanta', '', '', '0027109', '+40721558238', '066 7121200', '2011-02-20', '', 'singer, punker, icon', 'Garbage', 'Yes', '11', '2', 'Atomic Records', '', '', 'a4d6046cfc0ea3mackenzie-thumb.jpg', ''); 
INSERT INTO `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `linkedin`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3527', 'John', 'Lassiter', '2011-02-17', 'john.lassiter@linkedin.com', '56 Red Hill Street', '', 'Ohio', '', '', '0027348', '0034772582', '0034772583', '2011-02-26', '', 'welder, tinsmith, sandblaster', 'Nordik Worx', 'Yes', '15', '2', 'Nordik Worx', 'A nice guy, strong and workaholic.', '', 'a4d6042b1ad0131294859315_bluefish.png', ''); 
INSERT INTO `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `linkedin`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3530', 'Martina', 'Hennessy', '0000-00-00', '', 'kelfn', 'gklwgg', 'gklwg', 'Dublin', 'Ireland', '', '0-807655056', '098696777', '2011-04-07', '', 'Chartered Accountant
CFA
ACOI', 'AIB', '', '15', '2', 'reqf', 'CFA suitable for RIsk Manager
Complianec Officer
Internal Auditor
', 'Good in interview
Salary expectation 112323
Internal Audit
Compliance
Sent to Eperon', '', ''); 
INSERT INTO `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `linkedin`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3531', 'mary', 'ryan', '1982-05-07', '', 'fefg', 'rgrwqg', 'rqwgqwg', 'Dublin', 'Ireland', '', '97346394', '', '0000-00-00', '', 'solicitor
banking solicitor
compliance officer
company secretary
risk manager
PSL', '', '', '18', '1', '', 'random comment', '', '', ''); 
 
DROP TABLE IF EXISTS `phpmysqlautobackup`; 
CREATE TABLE `phpmysqlautobackup` (
  `id` int(11) NOT NULL,
  `version` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `time_last_run` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
INSERT INTO `phpmysqlautobackup` (`id`, `version`, `time_last_run`) values ('1', '1.5.5', '1302365289'); 
 
DROP TABLE IF EXISTS `phpmysqlautobackup_log`; 
CREATE TABLE `phpmysqlautobackup_log` (
  `date` int(11) NOT NULL,
  `bytes` int(11) NOT NULL,
  `lines` int(11) NOT NULL,
  PRIMARY KEY (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
INSERT INTO `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1298909768', '75801', '660'); 
 
DROP TABLE IF EXISTS `users`; 
CREATE TABLE `users` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `salt` varchar(3) COLLATE latin1_general_ci NOT NULL,
  `username` text COLLATE latin1_general_ci NOT NULL,
  `password` text COLLATE latin1_general_ci NOT NULL,
  `email` text COLLATE latin1_general_ci NOT NULL,
  `rank` int(11) NOT NULL,
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci; 
INSERT INTO `users` (`uid`, `salt`, `username`, `password`, `email`, `rank`) values ('1', 'abc', 'ciprian', '123456', 'cip_sb@yahoo.com', '0'); 
INSERT INTO `users` (`uid`, `salt`, `username`, `password`, `email`, `rank`) values ('7', '', 'nordik', 'redlight', '', '0'); 
