# MySQL backup version: 1.5.5
# 
# Database: crm
# Domain name: 127.0.0.1:4001
# (c)2011 127.0.0.1:4001
#
# Backup START time: 09:42:31
# Backup END time: 09:42:31
# Backup Date: 08 Apr 2011
 
DROP TABLE IF EXISTS `attachments`; 
CREATE TABLE `attachments` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `attachment` text COLLATE latin1_general_ci NOT NULL,
  `itemid` int(11) NOT NULL,
  UNIQUE KEY `aid` (`aid`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci; 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('2', 'functions.php', '1'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('5', 'settings.php', '1'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('6', 'bottom.php', '0'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('7', 'functions.php', '6'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('8', 'login_form.inc.php', '7'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('9', 'register_form.inc.php', '8'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('10', 'settings.php', '9'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('11', 'atdsmttnyq4.jpg', '0'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('12', 'be56bdb4fd3bca5de4352c8.jpg', '11'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('13', 'atdsmttnyq4.jpg', '3220'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('14', 'be56bdb4fd3bca5de4352c8.jpg', '3220'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('15', '4ca1c0759d66aaframe.htm', '3221'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('16', '4ca1c0759dcfclogo.png', '3221'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('17', '4ca1c0759e3fbrss.gif', '3221'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('18', '4ca1c0759ff2agp_snake01.jpg', '3221'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('19', '4ca1c0a8ba30faframe.htm', '3222'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('20', '4ca1c0a8ba9c4logo.png', '3222'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('21', '4ca1c0a8bb1aerss.gif', '3222'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('22', '4ca1c0a8bb709gp_snake01.jpg', '3222'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('23', '4ca1c51b6e8a0pariazasigur.gif', '1'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('37', '', '3224'); 
INSERT INTO `attachments` (`aid`, `attachment`, `itemid`) values ('31', '', '3223'); 
 
DROP TABLE IF EXISTS `categories`; 
CREATE TABLE `categories` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `categoryname` text COLLATE latin1_general_ci NOT NULL,
  KEY `cid` (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci; 
INSERT INTO `categories` (`cid`, `categoryname`) values ('3', 'programmer'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('4', 'painter'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('7', 'electrician'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('8', 'mechanic'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('9', 'metal locksmith'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('11', 'driver'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('12', 'locksmiths'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('13', 'welder'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('15', 'carpenter'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('16', 'heat insulator'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('17', 'smelter'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('18', 'blacksmith concreter'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('21', 'drywall mechanic'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('22', 'bricklayer '); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('24', 'economist'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('27', 'lawyer'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('29', 'builder'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('30', 'engineer'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('31', 'electromechanical'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('33', 'woodworking operator'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('35', 'labourer'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('36', 'technician'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('48', 'locksmith'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('42', 'shipbuilding locksmith'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('43', 'locksmith fitter aggregate'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('44', 'plumber'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('46', 'electronist'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('47', 'waterproof insulator'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('49', 'sandblaster'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('50', 'craner'); 
INSERT INTO `categories` (`cid`, `categoryname`) values ('51', 'machinist tools'); 
 
DROP TABLE IF EXISTS `items`; 
CREATE TABLE `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE latin1_general_ci NOT NULL,
  `lastname` text COLLATE latin1_general_ci NOT NULL,
  `birthdate` date NOT NULL,
  `email` text COLLATE latin1_general_ci NOT NULL,
  `address` text COLLATE latin1_general_ci NOT NULL,
  `address2` text COLLATE latin1_general_ci NOT NULL,
  `location` text COLLATE latin1_general_ci NOT NULL,
  `county` text COLLATE latin1_general_ci NOT NULL,
  `country` text COLLATE latin1_general_ci NOT NULL,
  `ci` text COLLATE latin1_general_ci NOT NULL,
  `phone` text COLLATE latin1_general_ci NOT NULL,
  `mobile` text COLLATE latin1_general_ci NOT NULL,
  `available` date NOT NULL,
  `diplomas` text COLLATE latin1_general_ci NOT NULL,
  `lastworkplace` text COLLATE latin1_general_ci NOT NULL,
  `driverlicense` text COLLATE latin1_general_ci NOT NULL,
  `category` tinyint(3) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `currentworkplace` text COLLATE latin1_general_ci NOT NULL,
  `description` text COLLATE latin1_general_ci NOT NULL,
  `notes` text COLLATE latin1_general_ci NOT NULL,
  `photo` text COLLATE latin1_general_ci NOT NULL,
  `resume` text COLLATE latin1_general_ci NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3530 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci; 
INSERT INTO `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3528', 'Jared', 'Eckhart', '1969-02-10', 'jared_1087@gmail.com', '26 Last House on the Left', '', 'London', '', '', '0012311', '0727465699', '057 8674315', '2011-02-28', 'programmer', 'Microsoft Corp.', 'No', '3', '2', 'M.I.T.', '', '', 'a4d9ebb74881ebdaniel-samantha-thumb.jpg', ''); 
INSERT INTO `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3529', 'Patti', 'Smith', '1969-02-12', 'patti@worldrecords.org', 'Phoenix Rd.', '', 'Atlanta', '', '', '0027109', '+40721558238', '066 7121200', '2011-02-20', 'singer, punker, icon', 'Garbage', 'Yes', '11', '2', 'Atomic Records', '', '', '', ''); 
INSERT INTO `items` (`id`, `name`, `lastname`, `birthdate`, `email`, `address`, `address2`, `location`, `county`, `country`, `ci`, `phone`, `mobile`, `available`, `diplomas`, `lastworkplace`, `driverlicense`, `category`, `status`, `currentworkplace`, `description`, `notes`, `photo`, `resume`) values ('3527', 'John', 'Lassiter', '2011-02-17', 'john.lassiter@linkedin.com', '56 Red Hill Street', '', 'Ohio', '', '', '0027348', '0034772582', '0034772583', '2011-02-26', 'welder, tinsmith, sandblaster', 'Nordik Worx', 'Yes', '15', '2', 'Nordik Worx', 'A nice guy, strong and workaholic.', '', 'a4d9ebb5d83a5falex-actor-headshots-theater-model-eugene-oregon-1.jpg', ''); 
 
DROP TABLE IF EXISTS `phpmysqlautobackup`; 
CREATE TABLE `phpmysqlautobackup` (
  `id` int(11) NOT NULL,
  `version` varchar(6) COLLATE latin1_general_ci DEFAULT NULL,
  `time_last_run` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci; 
INSERT INTO `phpmysqlautobackup` (`id`, `version`, `time_last_run`) values ('1', '1.5.5', '1302248551'); 
 
DROP TABLE IF EXISTS `phpmysqlautobackup_log`; 
CREATE TABLE `phpmysqlautobackup_log` (
  `date` int(11) NOT NULL,
  `bytes` int(11) NOT NULL,
  `lines` int(11) NOT NULL,
  PRIMARY KEY (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci; 
INSERT INTO `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1298907632', '32208', '82'); 
INSERT INTO `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1302222149', '32024', '81'); 
INSERT INTO `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1298907087', '32002', '80'); 
INSERT INTO `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1298907168', '32105', '81'); 
INSERT INTO `phpmysqlautobackup_log` (`date`, `bytes`, `lines`) values ('1298907198', '32208', '82'); 
 
DROP TABLE IF EXISTS `users`; 
CREATE TABLE `users` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `salt` varchar(3) COLLATE latin1_general_ci NOT NULL,
  `username` text COLLATE latin1_general_ci NOT NULL,
  `password` text COLLATE latin1_general_ci NOT NULL,
  `email` text COLLATE latin1_general_ci NOT NULL,
  `rank` int(11) NOT NULL,
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci; 
INSERT INTO `users` (`uid`, `salt`, `username`, `password`, `email`, `rank`) values ('1', 'abc', 'demo', 'demo', 'email@example.com', '0'); 
