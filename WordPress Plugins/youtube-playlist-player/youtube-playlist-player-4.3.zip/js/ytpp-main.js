(function($) {
    $(function() {
        var ycarousel = $('.ycarousel');

        // Carousel
        ycarousel.each(function(){
            var carousel = $('.ycarousel-container', this).jcarousel({
                'wrap': 'circular'
            });
            $('.ycarousel-prev', this).jcarouselControl({
                target: '-=1',
                carousel: carousel
            });
            $('.ycarousel-next', this).jcarouselControl({
                target: '+=1',
                carousel: carousel
            });
        });

        // Video window
        $('a', ycarousel).fancybox({
            padding: 0,
            closeBtn: false
        });
    })
})(jQuery)

jQuery(document).ready(function(){
	jQuery('.accordion h2').click(function(){
        if(jQuery(this).next().is(':hidden')) {
            jQuery('.accordion h2').removeClass('active').next().slideUp();
            jQuery(this).addClass('active').next().slideDown();
        }
        return false;
    });

    jQuery('#nowplaying a').click(function(){
        if(!jQuery('#video').is(':visible')) {
            jQuery('#video').slideDown('fast');
        } else {
            jQuery('#video').slideUp('fast');
        }
    });
});
