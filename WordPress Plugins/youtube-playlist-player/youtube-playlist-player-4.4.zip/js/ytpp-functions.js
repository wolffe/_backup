jQuery(document).ready(function($){
    $('.ytpp_colorPicker').wpColorPicker();
});
